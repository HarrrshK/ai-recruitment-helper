import type { Metadata } from 'next'
import { Download, Upload } from 'lucide-react'
import { buttonVariants } from '@/components/ui/button'
import { PageHeader } from '@/components/kit/primitives'
import { CandidatesTable } from '@/components/candidates/candidates-table'

export const metadata: Metadata = { title: 'Candidates' }

export default async function CandidatesPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>
}) {
  const { status } = await searchParams
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Candidates"
        description="Every applicant across your open roles, ranked by AI match against each job's requirements."
        actions={
          <>
            <button type="button" className={buttonVariants({ variant: 'ghost' })}>
              <Download aria-hidden="true" />
              Export
            </button>
            <button type="button" className={buttonVariants({ variant: 'default' })}>
              <Upload aria-hidden="true" />
              Import resumes
            </button>
          </>
        }
      />
      <CandidatesTable initialStatus={status} />
    </div>
  )
}
