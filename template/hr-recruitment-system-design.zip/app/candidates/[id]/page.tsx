import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ChevronLeft } from 'lucide-react'
import { candidates, getAssessment, getCandidate, getJob, interviews } from '@/lib/data'
import { Avatar, StatusBadge } from '@/components/kit/primitives'
import { AiAssessment } from '@/components/candidate/ai-assessment'
import { CandidateActions } from '@/components/candidate/candidate-actions'
import {
  DetailsPanel,
  InterviewHistory,
  ResumePanel,
  TimelinePanel,
} from '@/components/candidate/profile-sections'

export function generateStaticParams() {
  return candidates.map((c) => ({ id: c.id }))
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params
  return { title: getCandidate(id)?.name ?? 'Candidate' }
}

export default async function CandidatePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const candidate = getCandidate(id)
  if (!candidate) notFound()
  const job = getJob(candidate.jobId)
  const assessment = getAssessment(candidate)
  const history = interviews.filter((i) => i.candidateId === candidate.id)

  return (
    <div className="flex flex-col gap-6">
      <Link
        href="/candidates"
        className="inline-flex w-fit items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ChevronLeft className="size-4" aria-hidden="true" />
        Candidates
      </Link>

      <header className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
        <div className="flex items-center gap-4">
          <Avatar name={candidate.name} size="xl" />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="text-2xl font-semibold tracking-tight">{candidate.name}</h1>
              <StatusBadge status={candidate.status} />
            </div>
            <p className="mt-1 text-sm text-muted-foreground">
              {candidate.currentTitle} at {candidate.currentCompany} · {candidate.location}
            </p>
            <p className="mt-0.5 text-sm text-subtle-foreground">
              Applied for <span className="text-foreground">{job?.title}</span>
            </p>
          </div>
        </div>
        <CandidateActions name={candidate.name} initialStatus={candidate.status} />
      </header>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="flex min-w-0 flex-col gap-6 xl:col-span-2">
          <AiAssessment candidate={candidate} assessment={assessment} jobTitle={job?.title ?? ''} />
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <ResumePanel candidate={candidate} />
            <TimelinePanel candidate={candidate} />
          </div>
        </div>
        <div className="flex flex-col gap-6">
          <DetailsPanel candidate={candidate} job={job} />
          <InterviewHistory items={history} />
        </div>
      </div>
    </div>
  )
}
