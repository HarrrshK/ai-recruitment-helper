import type { Metadata } from 'next'
import Link from 'next/link'
import { Plus } from 'lucide-react'
import { jobs } from '@/lib/data'
import { buttonVariants } from '@/components/ui/button'
import { PageHeader } from '@/components/kit/primitives'
import { JobsList } from '@/components/jobs/jobs-list'

export const metadata: Metadata = { title: 'Jobs' }

export default function JobsPage() {
  const active = jobs.filter((j) => j.status === 'Active')
  const applicants = active.reduce((s, j) => s + j.applicants, 0)
  const shortlisted = active.reduce((s, j) => s + j.shortlisted, 0)
  const interviewsCount = active.reduce((s, j) => s + j.interviews, 0)

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Jobs"
        description={`${active.length} open roles · ${applicants.toLocaleString()} applicants · ${shortlisted} shortlisted · ${interviewsCount} in interviews`}
        actions={
          <Link href="/jobs/new" className={buttonVariants({ variant: 'default' })}>
            <Plus aria-hidden="true" />
            Create job
          </Link>
        }
      />
      <JobsList />
    </div>
  )
}
