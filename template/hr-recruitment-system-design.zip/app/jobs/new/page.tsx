import type { Metadata } from 'next'
import Link from 'next/link'
import { ChevronLeft } from 'lucide-react'
import { PageHeader } from '@/components/kit/primitives'
import { JobForm } from '@/components/jobs/job-form'

export const metadata: Metadata = { title: 'New job' }

export default function NewJobPage() {
  return (
    <div className="flex flex-col gap-6">
      <Link
        href="/jobs"
        className="inline-flex w-fit items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ChevronLeft className="size-4" aria-hidden="true" />
        Jobs
      </Link>
      <PageHeader
        title="Create job"
        description="Define the role and requirements. Relay uses these to evaluate and rank every applicant."
      />
      <JobForm />
    </div>
  )
}
