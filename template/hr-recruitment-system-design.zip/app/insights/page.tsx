import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowRight, RefreshCw, Sparkles } from 'lucide-react'
import { candidates, getJob, insights } from '@/lib/data'
import { buttonVariants } from '@/components/ui/button'
import { Avatar, PageHeader, Panel } from '@/components/kit/primitives'
import { MatchRing } from '@/components/kit/match-score'
import { InsightCard } from '@/components/insights/insight-card'

export const metadata: Metadata = { title: 'AI Insights' }

export default function InsightsPage() {
  const unreviewed = candidates
    .filter((c) => c.status === 'Applied' && c.match >= 84)
    .sort((a, b) => b.match - a.match)
    .slice(0, 5)

  const summary = [
    { label: 'Open insights', value: insights.length },
    { label: 'Need attention', value: insights.filter((i) => i.kind === 'risk').length },
    { label: 'Actions taken this week', value: 14 },
    { label: 'Hours saved on screening', value: 38 },
  ]

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="AI insights"
        description="Patterns Relay has found across your pipeline, each with a recommended next step."
        actions={
          <button type="button" className={buttonVariants({ variant: 'outline' })}>
            <RefreshCw aria-hidden="true" />
            Refresh analysis
          </button>
        }
      />

      <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border lg:grid-cols-4">
        {summary.map((s) => (
          <div key={s.label} className="bg-card px-5 py-4">
            <dt className="text-xs text-muted-foreground">{s.label}</dt>
            <dd className="mt-1.5 text-2xl font-semibold tracking-tight tabular">{s.value}</dd>
          </div>
        ))}
      </dl>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:col-span-2">
          {insights.map((i) => (
            <InsightCard key={i.id} insight={i} />
          ))}
        </div>

        <div className="flex flex-col gap-6">
          <Panel
            title={
              <span className="flex items-center gap-2">
                <Sparkles className="size-3.5 text-brand" aria-hidden="true" />
                Review next
              </span>
            }
            description="Highest-match applicants not yet reviewed"
            bodyClassName="p-0"
          >
            <ol className="divide-y divide-border">
              {unreviewed.map((c, idx) => (
                <li key={c.id}>
                  <Link
                    href={`/candidates/${c.id}`}
                    className="group flex items-center gap-3 px-5 py-3 transition-colors hover:bg-white/[0.02]"
                  >
                    <span className="w-4 text-xs tabular text-subtle-foreground">{idx + 1}</span>
                    <Avatar name={c.name} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium">{c.name}</span>
                      <span className="block truncate text-xs text-muted-foreground">
                        {getJob(c.jobId)?.title}
                      </span>
                    </span>
                    <MatchRing score={c.match} />
                  </Link>
                </li>
              ))}
            </ol>
            <div className="border-t border-border px-5 py-3">
              <Link
                href="/candidates?status=Applied"
                className="inline-flex items-center gap-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
              >
                Open review queue
                <ArrowRight className="size-3" aria-hidden="true" />
              </Link>
            </div>
          </Panel>

          <Panel title="How insights work">
            <p className="text-sm leading-relaxed text-muted-foreground">
              Relay compares every applicant against the job&apos;s requirements and your historical hiring
              outcomes. Insights are recalculated hourly and never make decisions on their own — every action
              requires a recruiter.
            </p>
          </Panel>
        </div>
      </div>
    </div>
  )
}
