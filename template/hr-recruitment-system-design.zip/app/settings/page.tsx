import type { Metadata } from 'next'
import { Avatar, Badge, PageHeader, Panel } from '@/components/kit/primitives'
import { Field, SelectField, inputClass } from '@/components/kit/controls'
import { Button } from '@/components/ui/button'

export const metadata: Metadata = { title: 'Settings' }

const team = [
  { name: 'Elena Sousa', email: 'elena@acme.com', role: 'Admin' },
  { name: 'Mara Lindqvist', email: 'mara@acme.com', role: 'Hiring manager' },
  { name: 'Ben Ortiz', email: 'ben@acme.com', role: 'Interviewer' },
  { name: 'Priya Raman', email: 'priya@acme.com', role: 'Recruiter' },
]

export default function SettingsPage() {
  return (
    <div className="flex max-w-3xl flex-col gap-6">
      <PageHeader title="Settings" description="Manage your workspace, team and AI screening defaults." />

      <Panel title="Workspace">
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <Field label="Company name" htmlFor="company">
            <input id="company" defaultValue="Acme Inc." className={inputClass} />
          </Field>
          <Field label="Careers page" htmlFor="careers">
            <input id="careers" defaultValue="careers.acme.com" className={inputClass} />
          </Field>
          <Field label="Default timezone">
            <SelectField label="Default timezone" defaultValue="Europe/Berlin" className="h-9 w-full">
              <option>Europe/Berlin</option>
              <option>Europe/London</option>
              <option>America/New_York</option>
            </SelectField>
          </Field>
          <Field label="Match threshold for shortlist" hint="Candidates above this score are suggested for the shortlist.">
            <SelectField label="Match threshold" defaultValue="85" className="h-9 w-full">
              {[75, 80, 85, 90].map((n) => (
                <option key={n} value={n}>{n}%</option>
              ))}
            </SelectField>
          </Field>
        </div>
        <div className="mt-6 flex justify-end">
          <Button>Save changes</Button>
        </div>
      </Panel>

      <Panel title="Team" action={<Button variant="outline" size="sm">Invite member</Button>} bodyClassName="p-0">
        <ul className="divide-y divide-border">
          {team.map((m) => (
            <li key={m.email} className="flex items-center gap-3 px-5 py-3">
              <Avatar name={m.name} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{m.name}</p>
                <p className="truncate text-xs text-muted-foreground">{m.email}</p>
              </div>
              <Badge tone={m.role === 'Admin' ? 'brand' : 'neutral'}>{m.role}</Badge>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  )
}
