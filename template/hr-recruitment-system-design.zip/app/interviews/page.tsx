import type { Metadata } from 'next'
import Link from 'next/link'
import { Building2, CalendarPlus, Star, Video } from 'lucide-react'
import { getCandidate, getJob, interviews, type Interview } from '@/lib/data'
import { buttonVariants } from '@/components/ui/button'
import { Avatar, Badge, PageHeader, Panel } from '@/components/kit/primitives'
import { MatchRing } from '@/components/kit/match-score'
import { cn } from '@/lib/utils'

export const metadata: Metadata = { title: 'Interviews' }

function InterviewRow({ interview }: { interview: Interview }) {
  const c = getCandidate(interview.candidateId)!
  const job = getJob(c.jobId)
  const ModeIcon = interview.mode === 'Video' ? Video : Building2
  return (
    <li className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:gap-5">
      <div className="flex w-24 shrink-0 items-baseline gap-2 sm:block">
        <p className="text-sm font-medium tabular">{interview.time}</p>
        <p className="text-xs text-subtle-foreground">{interview.duration} min</p>
      </div>
      <div className="flex min-w-0 flex-1 items-center gap-3">
        <Avatar name={c.name} />
        <div className="min-w-0">
          <Link href={`/candidates/${c.id}`} className="block truncate text-sm font-medium hover:underline">
            {c.name}
          </Link>
          <p className="truncate text-xs text-muted-foreground">
            {interview.stage} · {job?.title}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-4 sm:w-auto">
        <span className="hidden items-center gap-1.5 text-xs text-muted-foreground md:flex">
          <ModeIcon className="size-3.5" aria-hidden="true" />
          {interview.mode}
        </span>
        <span className="flex -space-x-1.5" aria-label={`Interviewers: ${interview.interviewers.join(', ')}`}>
          {interview.interviewers.map((n) => (
            <span key={n} className="rounded-full ring-2 ring-card">
              <Avatar name={n} size="sm" />
            </span>
          ))}
        </span>
        <MatchRing score={c.match} size={32} />
        <div className="ml-auto w-28 text-right sm:ml-0">
          {interview.rating ? (
            <span className="inline-flex items-center gap-0.5" aria-label={`Rated ${interview.rating} of 5`}>
              {Array.from({ length: 5 }, (_, n) => (
                <Star key={n} className={cn('size-3', n < interview.rating! ? 'fill-warning text-warning' : 'text-white/15')} aria-hidden="true" />
              ))}
            </span>
          ) : (
            <Badge tone={interview.status === 'Needs feedback' ? 'warning' : 'brand'} dot>
              {interview.status}
            </Badge>
          )}
        </div>
      </div>
    </li>
  )
}

export default function InterviewsPage() {
  const upcoming = interviews.filter((i) => i.status === 'Scheduled')
  const days = Array.from(new Set(upcoming.map((i) => `${i.day}|${i.date}`)))
  const feedback = interviews.filter((i) => i.status === 'Needs feedback')
  const past = interviews.filter((i) => i.status === 'Completed')

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Interviews"
        description={`${upcoming.length} scheduled this week · ${feedback.length} awaiting feedback`}
        actions={
          <Link href="/candidates?status=Shortlisted" className={buttonVariants({ variant: 'default' })}>
            <CalendarPlus aria-hidden="true" />
            Schedule interview
          </Link>
        }
      />

      {feedback.length > 0 && (
        <Panel
          title="Awaiting feedback"
          description="Scorecards are overdue. Candidates can't progress until feedback is in."
          className="border-warning/20"
          bodyClassName="p-0"
        >
          <ul className="divide-y divide-border">
            {feedback.map((i) => (
              <InterviewRow key={i.id} interview={i} />
            ))}
          </ul>
        </Panel>
      )}

      <div className="flex flex-col gap-6">
        {days.map((d) => {
          const [day, date] = d.split('|')
          const items = upcoming.filter((i) => i.day === day)
          return (
            <Panel
              key={d}
              title={
                <span className="flex items-baseline gap-2">
                  {day}
                  <span className="text-xs font-normal text-subtle-foreground">{date}</span>
                </span>
              }
              action={<span className="text-xs tabular text-subtle-foreground">{items.length} interviews</span>}
              bodyClassName="p-0"
            >
              <ul className="divide-y divide-border">
                {items.map((i) => (
                  <InterviewRow key={i.id} interview={i} />
                ))}
              </ul>
            </Panel>
          )
        })}
      </div>

      <Panel title="Completed" bodyClassName="p-0">
        <ul className="divide-y divide-border">
          {past.map((i) => (
            <InterviewRow key={i.id} interview={i} />
          ))}
        </ul>
      </Panel>
    </div>
  )
}
