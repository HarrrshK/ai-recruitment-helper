import type { Metadata } from 'next'
import { Download } from 'lucide-react'
import { sourcePerformance } from '@/lib/data'
import { buttonVariants } from '@/components/ui/button'
import { PageHeader, Panel } from '@/components/kit/primitives'
import { ApplicationsChart, QualityChart, TimeToHireChart } from '@/components/analytics/charts'
import { MatchInline } from '@/components/kit/match-score'
import { PipelineFunnel } from '@/components/dashboard/widgets'

export const metadata: Metadata = { title: 'Analytics' }

const kpis = [
  { label: 'Applications (30d)', value: '1,123', delta: '+12.4%' },
  { label: 'Avg. time to hire', value: '27 days', delta: '−14 days' },
  { label: 'Offer acceptance', value: '82%', delta: '+6 pts' },
  { label: 'Avg. match score', value: '74', delta: '+3' },
]

export default function AnalyticsPage() {
  const maxApplicants = Math.max(...sourcePerformance.map((s) => s.applicants))
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Analytics"
        description="Hiring performance across all roles · Aug 4 — Oct 9, 2026"
        actions={
          <button type="button" className={buttonVariants({ variant: 'outline' })}>
            <Download aria-hidden="true" />
            Export report
          </button>
        }
      />

      <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border lg:grid-cols-4">
        {kpis.map((k) => (
          <div key={k.label} className="bg-card px-5 py-4">
            <dt className="text-xs text-muted-foreground">{k.label}</dt>
            <dd className="mt-1.5 flex items-baseline gap-2">
              <span className="text-2xl font-semibold tracking-tight tabular">{k.value}</span>
              <span className="text-xs font-medium text-success tabular">{k.delta}</span>
            </dd>
          </div>
        ))}
      </dl>

      <Panel
        title="Applications over time"
        action={
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5"><span className="size-2 rounded-full bg-brand" aria-hidden="true" />Applications</span>
            <span className="flex items-center gap-1.5"><span className="size-2 rounded-full bg-success" aria-hidden="true" />Shortlisted</span>
          </div>
        }
      >
        <ApplicationsChart />
      </Panel>

      <PipelineFunnel />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Panel title="Time to hire" description="Average days from application to accepted offer">
          <TimeToHireChart />
        </Panel>
        <Panel title="Candidate quality" description="Distribution of AI match scores">
          <QualityChart />
        </Panel>
      </div>

      <Panel title="Source performance" description="Where your best candidates come from" bodyClassName="p-0">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-subtle-foreground">
                <th scope="col" className="px-5 py-2.5 font-medium">Source</th>
                <th scope="col" className="px-5 py-2.5 font-medium">Applicants</th>
                <th scope="col" className="px-5 py-2.5 font-medium">Avg. match</th>
                <th scope="col" className="px-5 py-2.5 text-right font-medium">Hires</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {sourcePerformance.map((s) => (
                <tr key={s.source}>
                  <td className="px-5 py-3 font-medium">{s.source}</td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <span className="w-10 tabular">{s.applicants}</span>
                      <div className="h-1.5 w-32 overflow-hidden rounded-full bg-white/[0.06]">
                        <div className="bar-in h-full rounded-full bg-brand/60" style={{ width: `${(s.applicants / maxApplicants) * 100}%` }} />
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3"><MatchInline score={s.avgMatch} /></td>
                  <td className="px-5 py-3 text-right tabular">{s.hires}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  )
}
