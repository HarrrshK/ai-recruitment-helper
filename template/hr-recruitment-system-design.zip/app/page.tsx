import Link from 'next/link'
import { Plus, Sparkles } from 'lucide-react'
import { insights } from '@/lib/data'
import { buttonVariants } from '@/components/ui/button'
import { PageHeader, Panel } from '@/components/kit/primitives'
import { InsightRow } from '@/components/insights/insight-card'
import {
  PipelineFunnel,
  RecentCandidates,
  StatGrid,
  UpcomingInterviews,
} from '@/components/dashboard/widgets'

export default function OverviewPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Friday, October 9"
        title="Good afternoon, Elena"
        description="12 high-match candidates are waiting for review and 2 interviews are scheduled today."
        actions={
          <>
            <Link href="/candidates" className={buttonVariants({ variant: 'outline' })}>
              Review queue
            </Link>
            <Link href="/jobs/new" className={buttonVariants({ variant: 'default' })}>
              <Plus aria-hidden="true" />
              New job
            </Link>
          </>
        }
      />

      <StatGrid />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="flex flex-col gap-6 xl:col-span-2">
          <PipelineFunnel />
          <RecentCandidates />
        </div>
        <div className="flex flex-col gap-6">
          <Panel
            title={
              <span className="flex items-center gap-2">
                <Sparkles className="size-3.5 text-brand" aria-hidden="true" />
                AI insights
              </span>
            }
            description="Updated 12 minutes ago"
            action={
              <Link href="/insights" className="text-xs text-muted-foreground transition-colors hover:text-foreground">
                All insights
              </Link>
            }
            bodyClassName="p-2"
          >
            <div className="flex flex-col">
              {insights.slice(0, 4).map((i) => (
                <InsightRow key={i.id} insight={i} />
              ))}
            </div>
          </Panel>
          <UpcomingInterviews />
        </div>
      </div>
    </div>
  )
}
