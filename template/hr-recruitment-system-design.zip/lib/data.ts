export type CandidateStatus =
  | 'Applied'
  | 'Screening'
  | 'Shortlisted'
  | 'Interview'
  | 'Offer'
  | 'Hired'
  | 'Rejected'

export type ResumeStatus = 'Parsed' | 'Processing' | 'Missing'

export type Candidate = {
  id: string
  name: string
  email: string
  phone: string
  location: string
  jobId: string
  currentTitle: string
  currentCompany: string
  experience: number
  education: { degree: string; school: string; year: number }
  skills: string[]
  status: CandidateStatus
  match: number
  resume: ResumeStatus
  source: 'LinkedIn' | 'Referral' | 'Careers page' | 'Wellfound' | 'Agency'
  appliedAt: string
  lastActivity: string
  lastActivityLabel: string
}

export type JobStatus = 'Active' | 'Draft' | 'Closed'

export type Job = {
  id: string
  title: string
  department: string
  location: string
  type: 'Full-time' | 'Contract' | 'Part-time'
  status: JobStatus
  minExperience: number
  skills: string[]
  niceToHave: string[]
  applicants: number
  shortlisted: number
  interviews: number
  hiringManager: string
  postedAt: string
}

export const jobs: Job[] = [
  {
    id: 'backend-engineer',
    title: 'Senior Backend Engineer',
    department: 'Engineering',
    location: 'Berlin · Hybrid',
    type: 'Full-time',
    status: 'Active',
    minExperience: 5,
    skills: ['C++', 'Go', 'PostgreSQL', 'Distributed systems', 'AWS'],
    niceToHave: ['Kafka', 'gRPC'],
    applicants: 184,
    shortlisted: 22,
    interviews: 9,
    hiringManager: 'Mara Lindqvist',
    postedAt: 'Sep 02',
  },
  {
    id: 'product-designer',
    title: 'Product Designer',
    department: 'Design',
    location: 'Remote · EU',
    type: 'Full-time',
    status: 'Active',
    minExperience: 4,
    skills: ['Figma', 'Design systems', 'Prototyping', 'User research'],
    niceToHave: ['Motion design'],
    applicants: 241,
    shortlisted: 18,
    interviews: 6,
    hiringManager: 'Theo Marchetti',
    postedAt: 'Aug 28',
  },
  {
    id: 'ml-engineer',
    title: 'Machine Learning Engineer',
    department: 'AI Platform',
    location: 'London · Onsite',
    type: 'Full-time',
    status: 'Active',
    minExperience: 4,
    skills: ['Python', 'PyTorch', 'MLOps', 'Kubernetes', 'SQL'],
    niceToHave: ['Ray', 'LLM fine-tuning'],
    applicants: 132,
    shortlisted: 14,
    interviews: 5,
    hiringManager: 'Priya Raman',
    postedAt: 'Sep 11',
  },
  {
    id: 'frontend-engineer',
    title: 'Frontend Engineer',
    department: 'Engineering',
    location: 'Remote · Global',
    type: 'Full-time',
    status: 'Active',
    minExperience: 3,
    skills: ['TypeScript', 'React', 'Next.js', 'CSS', 'Accessibility'],
    niceToHave: ['WebGL'],
    applicants: 312,
    shortlisted: 26,
    interviews: 11,
    hiringManager: 'Mara Lindqvist',
    postedAt: 'Aug 19',
  },
  {
    id: 'data-analyst',
    title: 'Data Analyst',
    department: 'Operations',
    location: 'Amsterdam · Hybrid',
    type: 'Contract',
    status: 'Active',
    minExperience: 2,
    skills: ['SQL', 'Python', 'dbt', 'Looker'],
    niceToHave: ['Statistics'],
    applicants: 96,
    shortlisted: 8,
    interviews: 3,
    hiringManager: 'Jonas Weber',
    postedAt: 'Sep 20',
  },
  {
    id: 'people-partner',
    title: 'People Partner',
    department: 'People',
    location: 'Berlin · Hybrid',
    type: 'Full-time',
    status: 'Draft',
    minExperience: 5,
    skills: ['Employee relations', 'Performance management', 'German'],
    niceToHave: ['HRIS'],
    applicants: 0,
    shortlisted: 0,
    interviews: 0,
    hiringManager: 'Elena Sousa',
    postedAt: '—',
  },
  {
    id: 'security-engineer',
    title: 'Security Engineer',
    department: 'Engineering',
    location: 'Remote · EU',
    type: 'Full-time',
    status: 'Draft',
    minExperience: 5,
    skills: ['AppSec', 'Threat modeling', 'Go', 'AWS'],
    niceToHave: ['SOC 2'],
    applicants: 0,
    shortlisted: 0,
    interviews: 0,
    hiringManager: 'Mara Lindqvist',
    postedAt: '—',
  },
  {
    id: 'account-executive',
    title: 'Account Executive, DACH',
    department: 'Sales',
    location: 'Munich · Onsite',
    type: 'Full-time',
    status: 'Closed',
    minExperience: 4,
    skills: ['Enterprise sales', 'German', 'Salesforce'],
    niceToHave: ['SaaS'],
    applicants: 158,
    shortlisted: 12,
    interviews: 7,
    hiringManager: 'Lukas Brandt',
    postedAt: 'Jun 14',
  },
]

const c = (data: Omit<Candidate, 'email' | 'phone'> & { email?: string }): Candidate => ({
  ...data,
  email: data.email ?? `${data.name.toLowerCase().split(' ').join('.')}@mail.com`,
  phone: '+49 151 0000 ' + String(data.match * 37).slice(0, 4),
})

export const candidates: Candidate[] = [
  c({
    id: 'aria-chen',
    name: 'Aria Chen',
    location: 'Berlin, DE',
    jobId: 'backend-engineer',
    currentTitle: 'Backend Engineer',
    currentCompany: 'Northbeam',
    experience: 7,
    education: { degree: 'M.Sc. Computer Science', school: 'TU München', year: 2017 },
    skills: ['C++', 'Go', 'PostgreSQL', 'Distributed systems', 'gRPC', 'Kafka'],
    status: 'Shortlisted',
    match: 92,
    resume: 'Parsed',
    source: 'Referral',
    appliedAt: 'Sep 24',
    lastActivity: '2h',
    lastActivityLabel: 'Moved to Shortlisted',
  }),
  c({
    id: 'daniel-okafor',
    name: 'Daniel Okafor',
    location: 'Lisbon, PT',
    jobId: 'frontend-engineer',
    currentTitle: 'Senior Frontend Engineer',
    currentCompany: 'Paylane',
    experience: 6,
    education: { degree: 'B.Eng. Software Engineering', school: 'University of Lagos', year: 2018 },
    skills: ['TypeScript', 'React', 'Next.js', 'CSS', 'Accessibility', 'WebGL'],
    status: 'Interview',
    match: 94,
    resume: 'Parsed',
    source: 'LinkedIn',
    appliedAt: 'Sep 18',
    lastActivity: '4h',
    lastActivityLabel: 'Technical interview scheduled',
  }),
  c({
    id: 'sofia-marin',
    name: 'Sofia Marín',
    location: 'Madrid, ES',
    jobId: 'product-designer',
    currentTitle: 'Product Designer',
    currentCompany: 'Fieldnote',
    experience: 5,
    education: { degree: 'B.A. Interaction Design', school: 'IED Madrid', year: 2019 },
    skills: ['Figma', 'Design systems', 'Prototyping', 'Motion design'],
    status: 'Screening',
    match: 88,
    resume: 'Parsed',
    source: 'Careers page',
    appliedAt: 'Oct 02',
    lastActivity: '6h',
    lastActivityLabel: 'Resume parsed',
  }),
  c({
    id: 'kenji-watanabe',
    name: 'Kenji Watanabe',
    location: 'London, UK',
    jobId: 'ml-engineer',
    currentTitle: 'ML Engineer',
    currentCompany: 'Corvid AI',
    experience: 5,
    education: { degree: 'M.Sc. Machine Learning', school: 'UCL', year: 2019 },
    skills: ['Python', 'PyTorch', 'MLOps', 'Ray', 'SQL'],
    status: 'Shortlisted',
    match: 89,
    resume: 'Parsed',
    source: 'Wellfound',
    appliedAt: 'Sep 29',
    lastActivity: '1d',
    lastActivityLabel: 'Added hiring manager note',
  }),
  c({
    id: 'leila-haddad',
    name: 'Leila Haddad',
    location: 'Paris, FR',
    jobId: 'backend-engineer',
    currentTitle: 'Software Engineer II',
    currentCompany: 'Qonto',
    experience: 5,
    education: { degree: 'Diplôme d’Ingénieur', school: 'École Polytechnique', year: 2019 },
    skills: ['Go', 'PostgreSQL', 'AWS', 'Distributed systems', 'Terraform'],
    status: 'Applied',
    match: 87,
    resume: 'Parsed',
    source: 'LinkedIn',
    appliedAt: 'Oct 07',
    lastActivity: '1d',
    lastActivityLabel: 'Applied',
  }),
  c({
    id: 'marcus-holm',
    name: 'Marcus Holm',
    location: 'Stockholm, SE',
    jobId: 'frontend-engineer',
    currentTitle: 'Frontend Developer',
    currentCompany: 'Klarity',
    experience: 3,
    education: { degree: 'B.Sc. Computer Science', school: 'KTH', year: 2021 },
    skills: ['TypeScript', 'React', 'CSS', 'Storybook'],
    status: 'Screening',
    match: 78,
    resume: 'Parsed',
    source: 'Careers page',
    appliedAt: 'Oct 01',
    lastActivity: '2d',
    lastActivityLabel: 'Screening call completed',
  }),
  c({
    id: 'nadia-petrov',
    name: 'Nadia Petrov',
    location: 'Warsaw, PL',
    jobId: 'data-analyst',
    currentTitle: 'BI Analyst',
    currentCompany: 'Allegro',
    experience: 3,
    education: { degree: 'M.Sc. Econometrics', school: 'Warsaw School of Economics', year: 2021 },
    skills: ['SQL', 'Python', 'dbt', 'Looker', 'Statistics'],
    status: 'Interview',
    match: 91,
    resume: 'Parsed',
    source: 'Referral',
    appliedAt: 'Sep 26',
    lastActivity: '2d',
    lastActivityLabel: 'Case study submitted',
  }),
  c({
    id: 'tomas-novak',
    name: 'Tomáš Novák',
    location: 'Prague, CZ',
    jobId: 'backend-engineer',
    currentTitle: 'Systems Engineer',
    currentCompany: 'Avast',
    experience: 9,
    education: { degree: 'M.Sc. Informatics', school: 'Charles University', year: 2015 },
    skills: ['C++', 'Rust', 'Distributed systems', 'Linux'],
    status: 'Applied',
    match: 81,
    resume: 'Parsed',
    source: 'Agency',
    appliedAt: 'Oct 06',
    lastActivity: '3d',
    lastActivityLabel: 'Applied',
  }),
  c({
    id: 'amara-singh',
    name: 'Amara Singh',
    location: 'Dublin, IE',
    jobId: 'product-designer',
    currentTitle: 'Senior Product Designer',
    currentCompany: 'Intercom',
    experience: 8,
    education: { degree: 'B.Des. Visual Communication', school: 'NCAD', year: 2016 },
    skills: ['Figma', 'Design systems', 'User research', 'Prototyping'],
    status: 'Offer',
    match: 95,
    resume: 'Parsed',
    source: 'LinkedIn',
    appliedAt: 'Sep 09',
    lastActivity: '3d',
    lastActivityLabel: 'Offer sent',
  }),
  c({
    id: 'jonah-reyes',
    name: 'Jonah Reyes',
    location: 'Remote',
    jobId: 'ml-engineer',
    currentTitle: 'Data Scientist',
    currentCompany: 'Spotify',
    experience: 4,
    education: { degree: 'M.Sc. Statistics', school: 'Stanford', year: 2020 },
    skills: ['Python', 'PyTorch', 'SQL', 'Statistics'],
    status: 'Screening',
    match: 74,
    resume: 'Processing',
    source: 'Careers page',
    appliedAt: 'Oct 08',
    lastActivity: '3d',
    lastActivityLabel: 'Resume uploaded',
  }),
  c({
    id: 'eva-lindgren',
    name: 'Eva Lindgren',
    location: 'Oslo, NO',
    jobId: 'frontend-engineer',
    currentTitle: 'UI Engineer',
    currentCompany: 'Vipps',
    experience: 4,
    education: { degree: 'B.Sc. Informatics', school: 'University of Oslo', year: 2020 },
    skills: ['TypeScript', 'React', 'Next.js', 'Accessibility'],
    status: 'Shortlisted',
    match: 90,
    resume: 'Parsed',
    source: 'Referral',
    appliedAt: 'Sep 30',
    lastActivity: '4d',
    lastActivityLabel: 'Moved to Shortlisted',
  }),
  c({
    id: 'omar-farouk',
    name: 'Omar Farouk',
    location: 'Cairo, EG',
    jobId: 'backend-engineer',
    currentTitle: 'Backend Developer',
    currentCompany: 'Swvl',
    experience: 4,
    education: { degree: 'B.Sc. Computer Engineering', school: 'Cairo University', year: 2020 },
    skills: ['Go', 'PostgreSQL', 'Redis', 'Docker'],
    status: 'Rejected',
    match: 63,
    resume: 'Parsed',
    source: 'LinkedIn',
    appliedAt: 'Sep 15',
    lastActivity: '5d',
    lastActivityLabel: 'Rejected after screening',
  }),
  c({
    id: 'hannah-becker',
    name: 'Hannah Becker',
    location: 'Hamburg, DE',
    jobId: 'data-analyst',
    currentTitle: 'Analytics Engineer',
    currentCompany: 'Otto',
    experience: 2,
    education: { degree: 'B.Sc. Mathematics', school: 'Universität Hamburg', year: 2022 },
    skills: ['SQL', 'dbt', 'Python'],
    status: 'Applied',
    match: 84,
    resume: 'Parsed',
    source: 'Careers page',
    appliedAt: 'Oct 08',
    lastActivity: '5d',
    lastActivityLabel: 'Applied',
  }),
  c({
    id: 'luca-ferrari',
    name: 'Luca Ferrari',
    location: 'Milan, IT',
    jobId: 'product-designer',
    currentTitle: 'UX Designer',
    currentCompany: 'Satispay',
    experience: 3,
    education: { degree: 'M.A. Product Design', school: 'Politecnico di Milano', year: 2021 },
    skills: ['Figma', 'User research', 'Prototyping'],
    status: 'Applied',
    match: 76,
    resume: 'Missing',
    source: 'Wellfound',
    appliedAt: 'Oct 05',
    lastActivity: '6d',
    lastActivityLabel: 'Awaiting resume',
  }),
  c({
    id: 'grace-kim',
    name: 'Grace Kim',
    location: 'Zurich, CH',
    jobId: 'ml-engineer',
    currentTitle: 'Research Engineer',
    currentCompany: 'Google',
    experience: 6,
    education: { degree: 'Ph.D. Computer Science', school: 'ETH Zürich', year: 2018 },
    skills: ['Python', 'PyTorch', 'Kubernetes', 'LLM fine-tuning', 'MLOps'],
    status: 'Hired',
    match: 96,
    resume: 'Parsed',
    source: 'Referral',
    appliedAt: 'Aug 22',
    lastActivity: '1w',
    lastActivityLabel: 'Offer accepted',
  }),
  c({
    id: 'samuel-adeyemi',
    name: 'Samuel Adeyemi',
    location: 'Manchester, UK',
    jobId: 'frontend-engineer',
    currentTitle: 'Software Engineer',
    currentCompany: 'Monzo',
    experience: 5,
    education: { degree: 'B.Sc. Computer Science', school: 'University of Manchester', year: 2019 },
    skills: ['TypeScript', 'React', 'Next.js', 'GraphQL'],
    status: 'Applied',
    match: 86,
    resume: 'Parsed',
    source: 'LinkedIn',
    appliedAt: 'Oct 07',
    lastActivity: '1w',
    lastActivityLabel: 'Applied',
  }),
  c({
    id: 'ines-duarte',
    name: 'Inês Duarte',
    location: 'Porto, PT',
    jobId: 'backend-engineer',
    currentTitle: 'Platform Engineer',
    currentCompany: 'Farfetch',
    experience: 6,
    education: { degree: 'M.Sc. Informatics Engineering', school: 'FEUP', year: 2018 },
    skills: ['Go', 'Kafka', 'PostgreSQL', 'AWS', 'Kubernetes'],
    status: 'Interview',
    match: 88,
    resume: 'Parsed',
    source: 'Careers page',
    appliedAt: 'Sep 21',
    lastActivity: '1w',
    lastActivityLabel: 'System design interview',
  }),
  c({
    id: 'felix-wagner',
    name: 'Felix Wagner',
    location: 'Vienna, AT',
    jobId: 'data-analyst',
    currentTitle: 'Junior Analyst',
    currentCompany: 'Bitpanda',
    experience: 1,
    education: { degree: 'B.Sc. Business Informatics', school: 'TU Wien', year: 2023 },
    skills: ['SQL', 'Excel', 'Looker'],
    status: 'Screening',
    match: 68,
    resume: 'Parsed',
    source: 'Careers page',
    appliedAt: 'Oct 03',
    lastActivity: '1w',
    lastActivityLabel: 'Screening questionnaire sent',
  }),
  c({
    id: 'yara-nasser',
    name: 'Yara Nasser',
    location: 'Remote',
    jobId: 'product-designer',
    currentTitle: 'Design Lead',
    currentCompany: 'Careem',
    experience: 9,
    education: { degree: 'B.F.A. Graphic Design', school: 'AUB', year: 2015 },
    skills: ['Figma', 'Design systems', 'User research', 'Prototyping', 'Motion design'],
    status: 'Applied',
    match: 93,
    resume: 'Parsed',
    source: 'Referral',
    appliedAt: 'Oct 08',
    lastActivity: '1w',
    lastActivityLabel: 'Applied',
  }),
  c({
    id: 'oliver-grant',
    name: 'Oliver Grant',
    location: 'Edinburgh, UK',
    jobId: 'ml-engineer',
    currentTitle: 'MLOps Engineer',
    currentCompany: 'Skyscanner',
    experience: 4,
    education: { degree: 'M.Sc. Data Science', school: 'University of Edinburgh', year: 2020 },
    skills: ['Python', 'MLOps', 'Kubernetes', 'SQL'],
    status: 'Applied',
    match: 85,
    resume: 'Parsed',
    source: 'Agency',
    appliedAt: 'Oct 07',
    lastActivity: '1w',
    lastActivityLabel: 'Applied',
  }),
]

export type Interview = {
  id: string
  candidateId: string
  stage: 'Screening call' | 'Technical' | 'System design' | 'Portfolio review' | 'Final' | 'Case study'
  day: string
  date: string
  time: string
  duration: number
  interviewers: string[]
  mode: 'Video' | 'Onsite'
  status: 'Scheduled' | 'Completed' | 'Needs feedback'
  rating?: number
}

export const interviews: Interview[] = [
  { id: 'i1', candidateId: 'daniel-okafor', stage: 'Technical', day: 'Today', date: 'Oct 09', time: '14:00', duration: 60, interviewers: ['Mara Lindqvist', 'Ben Ortiz'], mode: 'Video', status: 'Scheduled' },
  { id: 'i2', candidateId: 'aria-chen', stage: 'Technical', day: 'Today', date: 'Oct 09', time: '16:30', duration: 60, interviewers: ['Mara Lindqvist'], mode: 'Video', status: 'Scheduled' },
  { id: 'i3', candidateId: 'kenji-watanabe', stage: 'System design', day: 'Tomorrow', date: 'Oct 10', time: '10:00', duration: 75, interviewers: ['Priya Raman', 'Ali Kaya'], mode: 'Onsite', status: 'Scheduled' },
  { id: 'i4', candidateId: 'nadia-petrov', stage: 'Case study', day: 'Tomorrow', date: 'Oct 10', time: '13:00', duration: 45, interviewers: ['Jonas Weber'], mode: 'Video', status: 'Scheduled' },
  { id: 'i5', candidateId: 'eva-lindgren', stage: 'Technical', day: 'Mon', date: 'Oct 12', time: '11:00', duration: 60, interviewers: ['Ben Ortiz'], mode: 'Video', status: 'Scheduled' },
  { id: 'i6', candidateId: 'amara-singh', stage: 'Final', day: 'Mon', date: 'Oct 12', time: '15:00', duration: 45, interviewers: ['Theo Marchetti', 'Elena Sousa'], mode: 'Onsite', status: 'Scheduled' },
  { id: 'i7', candidateId: 'ines-duarte', stage: 'System design', day: 'Tue', date: 'Oct 06', time: '09:30', duration: 75, interviewers: ['Mara Lindqvist', 'Ali Kaya'], mode: 'Video', status: 'Needs feedback' },
  { id: 'i8', candidateId: 'marcus-holm', stage: 'Screening call', day: 'Mon', date: 'Oct 05', time: '10:00', duration: 30, interviewers: ['Elena Sousa'], mode: 'Video', status: 'Completed', rating: 3 },
  { id: 'i9', candidateId: 'sofia-marin', stage: 'Portfolio review', day: 'Fri', date: 'Oct 02', time: '14:00', duration: 60, interviewers: ['Theo Marchetti'], mode: 'Video', status: 'Completed', rating: 4 },
  { id: 'i10', candidateId: 'grace-kim', stage: 'Final', day: 'Wed', date: 'Sep 30', time: '11:00', duration: 45, interviewers: ['Priya Raman', 'Elena Sousa'], mode: 'Onsite', status: 'Completed', rating: 5 },
]

export type Insight = {
  id: string
  kind: 'opportunity' | 'risk' | 'trend'
  title: string
  detail: string
  scope: string
  action: string
  href: string
  impact: 'High' | 'Medium' | 'Low'
}

export const insights: Insight[] = [
  {
    id: 'in1',
    kind: 'opportunity',
    title: '12 high-match candidates have not been reviewed',
    detail: 'All score above 85% and have been waiting more than 3 days. Top applicants typically accept other offers within 10 days.',
    scope: 'Across 4 jobs',
    action: 'Review candidates',
    href: '/candidates?status=Applied',
    impact: 'High',
  },
  {
    id: 'in2',
    kind: 'risk',
    title: '3 candidates have strong technical matches but lack one required skill',
    detail: 'Aria Chen, Tomáš Novák and Samuel Adeyemi each miss a single requirement that could be assessed in interview rather than filtered out.',
    scope: 'Senior Backend Engineer, Frontend Engineer',
    action: 'Compare candidates',
    href: '/candidates',
    impact: 'Medium',
  },
  {
    id: 'in3',
    kind: 'trend',
    title: 'Backend Engineer converts 34% better than the previous opening',
    detail: 'Applicant-to-shortlist conversion is 12.0% vs. 8.9%. Referral share increased after the updated job description went live.',
    scope: 'Senior Backend Engineer',
    action: 'View job performance',
    href: '/analytics',
    impact: 'Low',
  },
  {
    id: 'in4',
    kind: 'risk',
    title: 'Interview feedback overdue for Inês Duarte',
    detail: 'System design interview was completed 3 days ago. Two interviewers have not submitted scorecards.',
    scope: 'Senior Backend Engineer',
    action: 'Request feedback',
    href: '/interviews',
    impact: 'High',
  },
  {
    id: 'in5',
    kind: 'opportunity',
    title: 'Product Designer pipeline is top-heavy',
    detail: '241 applicants but only 6 interviews. Consider adding a portfolio-based screening step to accelerate review.',
    scope: 'Product Designer',
    action: 'Adjust pipeline',
    href: '/jobs',
    impact: 'Medium',
  },
  {
    id: 'in6',
    kind: 'trend',
    title: 'Referral candidates score 11 points higher on average',
    detail: 'Mean AI match for referrals is 91% vs. 80% for all sources over the last 30 days.',
    scope: 'All jobs',
    action: 'Open source analytics',
    href: '/analytics',
    impact: 'Low',
  },
]

export const pipeline = [
  { stage: 'Applied', count: 1123 },
  { stage: 'Screening', count: 412 },
  { stage: 'Shortlisted', count: 100 },
  { stage: 'Interview', count: 41 },
  { stage: 'Hired', count: 9 },
] as const

export const applicationsOverTime = [
  { week: 'Aug 04', applications: 142, shortlisted: 11 },
  { week: 'Aug 11', applications: 168, shortlisted: 14 },
  { week: 'Aug 18', applications: 155, shortlisted: 12 },
  { week: 'Aug 25', applications: 201, shortlisted: 17 },
  { week: 'Sep 01', applications: 236, shortlisted: 19 },
  { week: 'Sep 08', applications: 219, shortlisted: 22 },
  { week: 'Sep 15', applications: 248, shortlisted: 21 },
  { week: 'Sep 22', applications: 274, shortlisted: 26 },
  { week: 'Sep 29', applications: 262, shortlisted: 28 },
  { week: 'Oct 06', applications: 291, shortlisted: 31 },
]

export const sourcePerformance = [
  { source: 'Referral', applicants: 118, avgMatch: 91, hires: 4 },
  { source: 'LinkedIn', applicants: 412, avgMatch: 79, hires: 2 },
  { source: 'Careers page', applicants: 386, avgMatch: 77, hires: 2 },
  { source: 'Wellfound', applicants: 141, avgMatch: 82, hires: 1 },
  { source: 'Agency', applicants: 66, avgMatch: 84, hires: 0 },
]

export const timeToHire = [
  { month: 'May', days: 41 },
  { month: 'Jun', days: 38 },
  { month: 'Jul', days: 36 },
  { month: 'Aug', days: 33 },
  { month: 'Sep', days: 29 },
  { month: 'Oct', days: 27 },
]

export const qualityDistribution = [
  { band: '<60', count: 214 },
  { band: '60–69', count: 286 },
  { band: '70–79', count: 331 },
  { band: '80–89', count: 208 },
  { band: '90+', count: 84 },
]

export function getJob(id: string) {
  return jobs.find((j) => j.id === id)
}

export function getCandidate(id: string) {
  return candidates.find((x) => x.id === id)
}

export type Assessment = {
  strengths: string[]
  concerns: string[]
  missing: string[]
  recommendation: string
  summary: string
  breakdown: { label: string; score: number }[]
}

export function getAssessment(candidate: Candidate): Assessment {
  const job = getJob(candidate.jobId)
  const required = job?.skills ?? []
  const matched = required.filter((s) => candidate.skills.includes(s))
  const missing = required.filter((s) => !candidate.skills.includes(s))
  const bonus = (job?.niceToHave ?? []).filter((s) => candidate.skills.includes(s))
  const expDelta = candidate.experience - (job?.minExperience ?? 0)

  const strengths = [
    ...matched.slice(0, 3).map((s) => `Demonstrated ${s} experience in production roles`),
    ...(expDelta >= 2 ? [`${candidate.experience} years of experience, ${expDelta} above requirement`] : []),
    ...bonus.slice(0, 1).map((s) => `Brings nice-to-have skill: ${s}`),
  ].slice(0, 4)

  const concerns = [
    ...(expDelta < 0 ? [`${Math.abs(expDelta)} year${Math.abs(expDelta) > 1 ? 's' : ''} below the experience requirement`] : []),
    ...(missing.length > 0 ? [`Limited evidence of ${missing[0]} in recent roles`] : []),
    ...(candidate.resume !== 'Parsed' ? ['Resume not fully parsed — assessment may be incomplete'] : []),
  ]

  const recommendation =
    candidate.match >= 88
      ? 'Strong candidate for technical interview.'
      : candidate.match >= 78
        ? 'Proceed to screening call to validate gaps.'
        : 'Hold — review against other applicants first.'

  const summary = `${candidate.name.split(' ')[0]} matches ${matched.length} of ${required.length} required skills for ${job?.title ?? 'this role'}, with ${candidate.experience} years in comparable positions at ${candidate.currentCompany}.`

  const clamp = (n: number) => Math.max(40, Math.min(99, Math.round(n)))
  const breakdown = [
    { label: 'Skills', score: clamp((matched.length / Math.max(required.length, 1)) * 100) },
    { label: 'Experience', score: clamp(70 + expDelta * 8) },
    { label: 'Role fit', score: clamp(candidate.match + 2) },
    { label: 'Education', score: clamp(candidate.match - 6) },
  ]

  return { strengths, concerns, missing, recommendation, summary, breakdown }
}
