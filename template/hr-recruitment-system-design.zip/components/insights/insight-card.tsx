import Link from 'next/link'
import { AlertTriangle, ArrowRight, Lightbulb, TrendingUp } from 'lucide-react'
import type { Insight } from '@/lib/data'
import { cn } from '@/lib/utils'
import { Badge } from '@/components/kit/primitives'

const kindMeta = {
  opportunity: { icon: Lightbulb, label: 'Opportunity', className: 'text-brand bg-brand/10' },
  risk: { icon: AlertTriangle, label: 'Needs attention', className: 'text-warning bg-warning/10' },
  trend: { icon: TrendingUp, label: 'Trend', className: 'text-success bg-success/10' },
} as const

export function InsightRow({ insight }: { insight: Insight }) {
  const meta = kindMeta[insight.kind]
  const Icon = meta.icon
  return (
    <Link
      href={insight.href}
      className="group flex gap-3 rounded-lg px-3 py-3 transition-colors hover:bg-white/[0.03]"
    >
      <span className={cn('mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md', meta.className)}>
        <Icon className="size-3.5" aria-hidden="true" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-sm leading-snug text-foreground">{insight.title}</span>
        <span className="mt-1 flex items-center gap-1 text-xs text-muted-foreground transition-colors group-hover:text-foreground">
          {insight.action}
          <ArrowRight className="size-3 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
        </span>
      </span>
    </Link>
  )
}

export function InsightCard({ insight }: { insight: Insight }) {
  const meta = kindMeta[insight.kind]
  const Icon = meta.icon
  return (
    <article className="group flex flex-col rounded-xl border border-border bg-card p-5 transition-colors hover:border-border-strong">
      <div className="flex items-center justify-between gap-3">
        <span className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
          <span className={cn('flex size-6 items-center justify-center rounded-md', meta.className)}>
            <Icon className="size-3.5" aria-hidden="true" />
          </span>
          {meta.label}
        </span>
        <Badge tone={insight.impact === 'High' ? 'warning' : 'neutral'}>{insight.impact} impact</Badge>
      </div>
      <h3 className="mt-4 text-pretty text-base font-medium leading-snug text-foreground">
        {insight.title}
      </h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{insight.detail}</p>
      <div className="mt-5 flex items-center justify-between gap-3 border-t border-border pt-4">
        <span className="truncate text-xs text-subtle-foreground">{insight.scope}</span>
        <Link
          href={insight.href}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-md bg-white/[0.04] px-2.5 py-1.5 text-xs font-medium text-foreground ring-1 ring-inset ring-white/10 transition-colors hover:bg-white/[0.08]"
        >
          {insight.action}
          <ArrowRight className="size-3 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
        </Link>
      </div>
    </article>
  )
}
