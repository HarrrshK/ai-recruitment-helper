'use client'

import { useRef, useState } from 'react'
import { CalendarPlus, Check, Star, X } from 'lucide-react'
import type { CandidateStatus } from '@/lib/data'
import { Button } from '@/components/ui/button'
import { Field, SelectField, inputClass } from '@/components/kit/controls'
import { StatusBadge } from '@/components/kit/primitives'

export function CandidateActions({
  name,
  initialStatus,
  layout = 'row',
}: {
  name: string
  initialStatus: CandidateStatus
  layout?: 'row' | 'stack'
}) {
  const [status, setStatus] = useState<CandidateStatus>(initialStatus)
  const [notice, setNotice] = useState<string | null>(null)
  const dialogRef = useRef<HTMLDialogElement>(null)
  const firstName = name.split(' ')[0]

  const update = (next: CandidateStatus, message: string) => {
    setStatus(next)
    setNotice(message)
  }

  const shortlisted = status === 'Shortlisted' || status === 'Interview' || status === 'Offer' || status === 'Hired'
  const rejected = status === 'Rejected'

  return (
    <div className="flex flex-col gap-3">
      <div className={layout === 'stack' ? 'grid grid-cols-1 gap-2' : 'flex flex-wrap items-center gap-2'}>
        <Button
          variant={shortlisted ? 'secondary' : 'outline'}
          disabled={rejected}
          onClick={() =>
            shortlisted
              ? update('Screening', `${firstName} moved back to Screening.`)
              : update('Shortlisted', `${firstName} added to the shortlist.`)
          }
        >
          {shortlisted ? <Check aria-hidden="true" className="text-brand" /> : <Star aria-hidden="true" />}
          {shortlisted ? 'Shortlisted' : 'Shortlist'}
        </Button>
        <Button variant="brand" disabled={rejected} onClick={() => dialogRef.current?.showModal()}>
          <CalendarPlus aria-hidden="true" />
          Schedule interview
        </Button>
        <Button
          variant="destructive"
          onClick={() =>
            rejected
              ? update('Screening', `${firstName} restored to Screening.`)
              : update('Rejected', `${firstName} was rejected. A notification email is queued.`)
          }
        >
          <X aria-hidden="true" />
          {rejected ? 'Undo reject' : 'Reject'}
        </Button>
      </div>

      <div aria-live="polite" className="min-h-5 text-xs text-muted-foreground">
        {notice && (
          <span className="flex items-center gap-2">
            <StatusBadge status={status} />
            {notice}
          </span>
        )}
      </div>

      <dialog
        ref={dialogRef}
        aria-labelledby="schedule-title"
        className="m-auto w-[min(92vw,440px)] rounded-xl border border-border-strong bg-popover p-0 text-foreground shadow-2xl backdrop:bg-black/60 backdrop:backdrop-blur-[2px]"
      >
        <form
          method="dialog"
          onSubmit={() => update('Interview', `Technical interview with ${firstName} scheduled. Invites sent.`)}
        >
          <div className="border-b border-border px-5 py-4">
            <h2 id="schedule-title" className="text-sm font-medium">Schedule interview</h2>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Invites will be sent to {name} and the selected interviewers.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4 px-5 py-5">
            <Field label="Stage" className="col-span-2">
              <SelectField label="Stage" defaultValue="Technical" className="w-full">
                <option>Screening call</option>
                <option>Technical</option>
                <option>System design</option>
                <option>Final</option>
              </SelectField>
            </Field>
            <Field label="Date" htmlFor="iv-date">
              <input id="iv-date" type="date" defaultValue="2026-10-13" className={inputClass} required />
            </Field>
            <Field label="Time" htmlFor="iv-time">
              <input id="iv-time" type="time" defaultValue="14:00" className={inputClass} required />
            </Field>
            <Field label="Interviewers" htmlFor="iv-who" className="col-span-2">
              <input id="iv-who" defaultValue="Mara Lindqvist, Ben Ortiz" className={inputClass} />
            </Field>
          </div>
          <div className="flex justify-end gap-2 border-t border-border px-5 py-3">
            <Button type="button" variant="ghost" onClick={() => dialogRef.current?.close()}>
              Cancel
            </Button>
            <Button type="submit" variant="brand">Send invites</Button>
          </div>
        </form>
      </dialog>
    </div>
  )
}
