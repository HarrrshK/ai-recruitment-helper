import { Download, ExternalLink, FileText, GraduationCap, Mail, MapPin, Phone, Star } from 'lucide-react'
import type { Candidate, Interview, Job } from '@/lib/data'
import { cn } from '@/lib/utils'
import { Badge, Panel, ResumeBadge, SkillTag } from '@/components/kit/primitives'

export function DetailsPanel({ candidate, job }: { candidate: Candidate; job?: Job }) {
  const rows = [
    { icon: Mail, label: 'Email', value: candidate.email },
    { icon: Phone, label: 'Phone', value: candidate.phone },
    { icon: MapPin, label: 'Location', value: candidate.location },
  ]
  return (
    <Panel title="Profile" bodyClassName="flex flex-col gap-5">
      <dl className="grid grid-cols-2 gap-4">
        <div>
          <dt className="text-xs text-subtle-foreground">Experience</dt>
          <dd className="mt-1 text-sm font-medium tabular">{candidate.experience} years</dd>
        </div>
        <div>
          <dt className="text-xs text-subtle-foreground">Source</dt>
          <dd className="mt-1 text-sm font-medium">{candidate.source}</dd>
        </div>
        <div>
          <dt className="text-xs text-subtle-foreground">Applied</dt>
          <dd className="mt-1 text-sm font-medium">{candidate.appliedAt}</dd>
        </div>
        <div>
          <dt className="text-xs text-subtle-foreground">Notice period</dt>
          <dd className="mt-1 text-sm font-medium">1 month</dd>
        </div>
      </dl>

      <div className="flex items-start gap-3 rounded-lg border border-border bg-white/[0.02] p-3">
        <GraduationCap className="mt-0.5 size-4 shrink-0 text-subtle-foreground" aria-hidden="true" />
        <div className="min-w-0">
          <p className="text-sm font-medium">{candidate.education.degree}</p>
          <p className="text-xs text-muted-foreground">
            {candidate.education.school} · {candidate.education.year}
          </p>
        </div>
      </div>

      <div>
        <p className="text-xs text-subtle-foreground">Skills</p>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {candidate.skills.map((s) => (
            <SkillTag key={s} highlight={job?.skills.includes(s)}>{s}</SkillTag>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-subtle-foreground">Highlighted skills match job requirements.</p>
      </div>

      <ul className="flex flex-col gap-2 border-t border-border pt-4">
        {rows.map((r) => (
          <li key={r.label} className="flex items-center gap-2.5 text-sm">
            <r.icon className="size-3.5 text-subtle-foreground" aria-hidden="true" />
            <span className="sr-only">{r.label}:</span>
            <span className="truncate text-muted-foreground">{r.value}</span>
          </li>
        ))}
      </ul>
    </Panel>
  )
}

export function ResumePanel({ candidate }: { candidate: Candidate }) {
  const history = [
    { title: candidate.currentTitle, company: candidate.currentCompany, period: `${2026 - Math.min(candidate.experience, 3)} — Present` },
    { title: candidate.experience > 4 ? 'Software Engineer' : 'Junior Engineer', company: 'Previous employer', period: `${candidate.education.year + 1} — ${2026 - Math.min(candidate.experience, 3)}` },
  ]
  return (
    <Panel
      title="Resume"
      action={
        <div className="flex items-center gap-2">
          <ResumeBadge status={candidate.resume} />
          <button type="button" className="inline-flex size-7 items-center justify-center rounded-md text-muted-foreground hover:bg-white/[0.05] hover:text-foreground" aria-label="Download resume">
            <Download className="size-3.5" />
          </button>
          <button type="button" className="inline-flex size-7 items-center justify-center rounded-md text-muted-foreground hover:bg-white/[0.05] hover:text-foreground" aria-label="Open resume in new tab">
            <ExternalLink className="size-3.5" />
          </button>
        </div>
      }
    >
      <div className="flex items-center gap-3 rounded-lg border border-border bg-white/[0.02] p-3">
        <span className="flex size-9 items-center justify-center rounded-md bg-white/[0.05]">
          <FileText className="size-4 text-muted-foreground" aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium">
            {candidate.name.toLowerCase().replace(/\s+/g, '-')}-cv.pdf
          </p>
          <p className="text-xs text-subtle-foreground">2 pages · 184 KB · uploaded {candidate.appliedAt}</p>
        </div>
      </div>

      <h3 className="mt-5 text-xs font-medium uppercase tracking-wider text-subtle-foreground">Parsed work history</h3>
      <ol className="mt-3 flex flex-col gap-3">
        {history.map((h) => (
          <li key={h.title + h.period} className="flex items-baseline justify-between gap-4">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{h.title}</p>
              <p className="truncate text-xs text-muted-foreground">{h.company}</p>
            </div>
            <span className="shrink-0 text-xs tabular text-subtle-foreground">{h.period}</span>
          </li>
        ))}
      </ol>
    </Panel>
  )
}

const stageOrder = ['Applied', 'Screening', 'Shortlisted', 'Interview', 'Offer', 'Hired'] as const

export function TimelinePanel({ candidate }: { candidate: Candidate }) {
  const reachedIndex = candidate.status === 'Rejected' ? 1 : stageOrder.indexOf(candidate.status as (typeof stageOrder)[number])
  const events = [
    { label: 'Applied via ' + candidate.source, when: candidate.appliedAt, by: 'System' },
    { label: 'Resume parsed and AI evaluated', when: candidate.appliedAt, by: 'Relay AI' },
    ...(reachedIndex >= 1 ? [{ label: 'Moved to Screening', when: 'Oct 03', by: 'Elena Sousa' }] : []),
    ...(reachedIndex >= 2 ? [{ label: 'Added to shortlist', when: 'Oct 06', by: 'Mara Lindqvist' }] : []),
    ...(reachedIndex >= 3 ? [{ label: 'Interview scheduled', when: 'Oct 07', by: 'Elena Sousa' }] : []),
    ...(candidate.status === 'Rejected' ? [{ label: 'Rejected after screening', when: 'Oct 04', by: 'Elena Sousa' }] : []),
  ].reverse()

  return (
    <Panel title="Application timeline">
      <ol aria-label="Pipeline progress" className="mb-6 flex items-center gap-1">
        {stageOrder.map((s, i) => (
          <li key={s} className="flex flex-1 flex-col gap-1.5">
            <span
              className={cn(
                'h-1 rounded-full',
                candidate.status === 'Rejected' && i <= reachedIndex
                  ? 'bg-danger/60'
                  : i <= reachedIndex
                    ? 'bg-brand'
                    : 'bg-white/[0.06]',
              )}
            />
            <span className={cn('hidden text-[11px] sm:block', i <= reachedIndex ? 'text-foreground' : 'text-subtle-foreground')}>
              {s}
            </span>
          </li>
        ))}
      </ol>
      <ol className="relative flex flex-col gap-4 border-l border-border pl-5">
        {events.map((e, i) => (
          <li key={e.label} className="relative">
            <span
              aria-hidden="true"
              className={cn(
                'absolute -left-[25px] top-1.5 size-2 rounded-full ring-4 ring-card',
                i === 0 ? 'bg-brand' : 'bg-white/20',
              )}
            />
            <p className="text-sm">{e.label}</p>
            <p className="text-xs text-subtle-foreground">
              {e.when} · {e.by}
            </p>
          </li>
        ))}
      </ol>
    </Panel>
  )
}

export function InterviewHistory({ items }: { items: Interview[] }) {
  return (
    <Panel title="Interviews" bodyClassName={items.length ? 'p-0' : undefined}>
      {items.length === 0 ? (
        <p className="text-sm text-muted-foreground">No interviews yet.</p>
      ) : (
        <ul className="divide-y divide-border">
          {items.map((i) => (
            <li key={i.id} className="flex items-center justify-between gap-3 px-5 py-3">
              <div className="min-w-0">
                <p className="text-sm font-medium">{i.stage}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {i.date} · {i.time} · {i.interviewers.join(', ')}
                </p>
              </div>
              {i.rating ? (
                <span className="flex items-center gap-0.5" aria-label={`Rated ${i.rating} of 5`}>
                  {Array.from({ length: 5 }, (_, n) => (
                    <Star key={n} className={cn('size-3', n < i.rating! ? 'fill-warning text-warning' : 'text-white/15')} aria-hidden="true" />
                  ))}
                </span>
              ) : (
                <Badge tone={i.status === 'Needs feedback' ? 'warning' : 'brand'}>{i.status}</Badge>
              )}
            </li>
          ))}
        </ul>
      )}
    </Panel>
  )
}
