import { AlertTriangle, ArrowRight, Check, CircleDashed, Sparkles } from 'lucide-react'
import type { Assessment, Candidate } from '@/lib/data'
import { MatchRing, ScoreBar, scoreColor } from '@/components/kit/match-score'
import { cn } from '@/lib/utils'

export function AiAssessment({
  candidate,
  assessment,
  jobTitle,
}: {
  candidate: Candidate
  assessment: Assessment
  jobTitle: string
}) {
  const label = candidate.match >= 88 ? 'Strong match' : candidate.match >= 78 ? 'Good match' : 'Partial match'
  return (
    <section
      aria-labelledby="assessment-title"
      className="relative overflow-hidden rounded-xl border border-border bg-card"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand/60 to-transparent"
      />
      <header className="flex items-center justify-between gap-4 border-b border-border px-5 py-4">
        <div className="flex items-center gap-2">
          <Sparkles className="size-4 text-brand" aria-hidden="true" />
          <h2 id="assessment-title" className="text-sm font-medium">AI assessment</h2>
          <span className="text-xs text-subtle-foreground">for {jobTitle}</span>
        </div>
        <span className="text-xs text-subtle-foreground">Evaluated 2h ago</span>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-[260px_1fr]">
        <div className="flex flex-col gap-5 border-b border-border p-5 md:border-b-0 md:border-r">
          <div className="flex items-center gap-4">
            <MatchRing score={candidate.match} size={88} stroke={5} />
            <div>
              <p className={cn('text-sm font-medium', scoreColor(candidate.match))}>{label}</p>
              <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                Top {candidate.match >= 90 ? '5' : candidate.match >= 85 ? '10' : '25'}% of applicants
              </p>
            </div>
          </div>
          <div className="flex flex-col gap-2.5">
            {assessment.breakdown.map((b) => (
              <ScoreBar key={b.label} label={b.label} score={b.score} />
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-5 p-5">
          <p className="text-sm leading-relaxed text-muted-foreground">{assessment.summary}</p>

          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <div>
              <h3 className="text-xs font-medium uppercase tracking-wider text-subtle-foreground">Strengths</h3>
              <ul className="mt-2.5 flex flex-col gap-2">
                {assessment.strengths.map((s) => (
                  <li key={s} className="flex gap-2 text-sm leading-snug">
                    <Check className="mt-0.5 size-3.5 shrink-0 text-success" aria-hidden="true" />
                    {s}
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex flex-col gap-5">
              <div>
                <h3 className="text-xs font-medium uppercase tracking-wider text-subtle-foreground">Concerns</h3>
                <ul className="mt-2.5 flex flex-col gap-2">
                  {assessment.concerns.length === 0 && (
                    <li className="text-sm text-muted-foreground">No significant concerns found.</li>
                  )}
                  {assessment.concerns.map((s) => (
                    <li key={s} className="flex gap-2 text-sm leading-snug">
                      <AlertTriangle className="mt-0.5 size-3.5 shrink-0 text-warning" aria-hidden="true" />
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
              {assessment.missing.length > 0 && (
                <div>
                  <h3 className="text-xs font-medium uppercase tracking-wider text-subtle-foreground">
                    Missing requirements
                  </h3>
                  <ul className="mt-2.5 flex flex-wrap gap-1.5">
                    {assessment.missing.map((m) => (
                      <li
                        key={m}
                        className="inline-flex items-center gap-1 rounded-md border border-dashed border-warning/30 px-1.5 py-0.5 text-xs text-warning"
                      >
                        <CircleDashed className="size-3" aria-hidden="true" />
                        {m}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-start gap-3 rounded-lg border border-brand/20 bg-brand/[0.06] p-3.5">
            <ArrowRight className="mt-0.5 size-4 shrink-0 text-brand" aria-hidden="true" />
            <div>
              <p className="text-xs font-medium uppercase tracking-wider text-[oklch(0.8_0.08_278)]">
                Recommended action
              </p>
              <p className="mt-1 text-sm font-medium text-foreground">{assessment.recommendation}</p>
              {assessment.missing.length > 0 && (
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  Include a focused question on {assessment.missing.join(' and ')} in the interview guide.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
