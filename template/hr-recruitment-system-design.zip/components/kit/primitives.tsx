import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'
import type { CandidateStatus, JobStatus, ResumeStatus } from '@/lib/data'

export function PageHeader({
  title,
  description,
  actions,
  eyebrow,
}: {
  title: string
  description?: string
  actions?: ReactNode
  eyebrow?: string
}) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="min-w-0">
        {eyebrow && (
          <p className="mb-1.5 text-xs font-medium text-subtle-foreground">{eyebrow}</p>
        )}
        <h1 className="text-pretty text-2xl font-semibold tracking-tight text-foreground">
          {title}
        </h1>
        {description && (
          <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-muted-foreground">
            {description}
          </p>
        )}
      </div>
      {actions && <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}

export function Panel({
  title,
  description,
  action,
  children,
  className,
  bodyClassName,
}: {
  title?: ReactNode
  description?: string
  action?: ReactNode
  children: ReactNode
  className?: string
  bodyClassName?: string
}) {
  return (
    <section
      className={cn(
        'rounded-xl border border-border bg-card shadow-[0_1px_0_oklch(1_0_0/3%)_inset]',
        className,
      )}
    >
      {(title || action) && (
        <header className="flex items-start justify-between gap-4 border-b border-border px-5 py-4">
          <div className="min-w-0">
            {title && <h2 className="text-sm font-medium text-foreground">{title}</h2>}
            {description && (
              <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{description}</p>
            )}
          </div>
          {action}
        </header>
      )}
      <div className={cn('p-5', bodyClassName)}>{children}</div>
    </section>
  )
}

const hues = [
  'bg-[oklch(0.32_0.06_278)] text-[oklch(0.9_0.05_278)]',
  'bg-[oklch(0.32_0.05_200)] text-[oklch(0.9_0.05_200)]',
  'bg-[oklch(0.32_0.05_160)] text-[oklch(0.9_0.05_160)]',
  'bg-[oklch(0.32_0.05_40)] text-[oklch(0.9_0.05_40)]',
  'bg-[oklch(0.3_0.01_275)] text-[oklch(0.88_0.01_275)]',
]

export function Avatar({ name, size = 'md' }: { name: string; size?: 'sm' | 'md' | 'lg' | 'xl' }) {
  const initials = name
    .split(' ')
    .map((n) => n[0])
    .slice(0, 2)
    .join('')
  const hue = hues[name.charCodeAt(0) % hues.length]
  const sizes = {
    sm: 'size-6 text-[10px]',
    md: 'size-8 text-xs',
    lg: 'size-10 text-sm',
    xl: 'size-16 text-xl',
  }
  return (
    <span
      aria-hidden="true"
      className={cn(
        'inline-flex shrink-0 items-center justify-center rounded-full font-medium ring-1 ring-inset ring-white/10',
        hue,
        sizes[size],
      )}
    >
      {initials}
    </span>
  )
}

type Tone = 'neutral' | 'brand' | 'success' | 'warning' | 'danger'

const toneClasses: Record<Tone, string> = {
  neutral: 'text-muted-foreground bg-white/[0.04] ring-white/10',
  brand: 'text-[oklch(0.82_0.1_278)] bg-brand/10 ring-brand/25',
  success: 'text-success bg-success/10 ring-success/20',
  warning: 'text-warning bg-warning/10 ring-warning/20',
  danger: 'text-danger bg-danger/10 ring-danger/20',
}

const dotClasses: Record<Tone, string> = {
  neutral: 'bg-subtle-foreground',
  brand: 'bg-brand',
  success: 'bg-success',
  warning: 'bg-warning',
  danger: 'bg-danger',
}

export function Badge({
  tone = 'neutral',
  dot,
  children,
  className,
}: {
  tone?: Tone
  dot?: boolean
  children: ReactNode
  className?: string
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 whitespace-nowrap rounded-md px-1.5 py-0.5 text-xs font-medium ring-1 ring-inset',
        toneClasses[tone],
        className,
      )}
    >
      {dot && <span className={cn('size-1.5 rounded-full', dotClasses[tone])} />}
      {children}
    </span>
  )
}

export const statusTone: Record<CandidateStatus, Tone> = {
  Applied: 'neutral',
  Screening: 'neutral',
  Shortlisted: 'brand',
  Interview: 'brand',
  Offer: 'success',
  Hired: 'success',
  Rejected: 'danger',
}

export function StatusBadge({ status }: { status: CandidateStatus }) {
  return (
    <Badge tone={statusTone[status]} dot>
      {status}
    </Badge>
  )
}

export function JobStatusBadge({ status }: { status: JobStatus }) {
  const tone: Tone = status === 'Active' ? 'success' : status === 'Draft' ? 'neutral' : 'danger'
  return (
    <Badge tone={tone} dot>
      {status}
    </Badge>
  )
}

export function ResumeBadge({ status }: { status: ResumeStatus }) {
  const tone: Tone = status === 'Parsed' ? 'neutral' : status === 'Processing' ? 'warning' : 'danger'
  return <Badge tone={tone}>{status}</Badge>
}

export function SkillTag({ children, highlight }: { children: ReactNode; highlight?: boolean }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-md border px-1.5 py-0.5 text-xs',
        highlight
          ? 'border-brand/25 bg-brand/[0.07] text-foreground'
          : 'border-border bg-white/[0.02] text-muted-foreground',
      )}
    >
      {children}
    </span>
  )
}

export function Kbd({ children }: { children: ReactNode }) {
  return (
    <kbd className="inline-flex h-5 min-w-5 items-center justify-center rounded border border-border-strong bg-white/[0.03] px-1 font-mono text-[10px] text-subtle-foreground">
      {children}
    </kbd>
  )
}
