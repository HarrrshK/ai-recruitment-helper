import type { CSSProperties } from 'react'
import { cn } from '@/lib/utils'

export function scoreColor(score: number) {
  if (score >= 85) return 'text-[oklch(0.8_0.11_278)]'
  if (score >= 70) return 'text-foreground'
  return 'text-warning'
}

function strokeColor(score: number) {
  if (score >= 85) return 'stroke-brand'
  if (score >= 70) return 'stroke-[oklch(0.75_0.01_275)]'
  return 'stroke-warning'
}

export function MatchRing({
  score,
  size = 36,
  stroke = 3,
  showValue = true,
  className,
}: {
  score: number
  size?: number
  stroke?: number
  showValue?: boolean
  className?: string
}) {
  const r = (size - stroke) / 2
  return (
    <span
      className={cn('relative inline-flex shrink-0 items-center justify-center', className)}
      style={{ width: size, height: size }}
      role="img"
      aria-label={`${score}% AI match`}
    >
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          strokeWidth={stroke}
          className="stroke-white/[0.07]"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          strokeWidth={stroke}
          strokeLinecap="round"
          pathLength={100}
          className={cn('score-ring', strokeColor(score))}
          style={{ '--score': score } as CSSProperties}
        />
      </svg>
      {showValue && (
        <span
          className={cn(
            'absolute inset-0 flex items-center justify-center font-medium tabular',
            size >= 80 ? 'text-2xl tracking-tight' : 'text-[11px]',
            scoreColor(score),
          )}
        >
          {score}
          {size >= 80 && <span className="ml-0.5 text-sm text-muted-foreground">%</span>}
        </span>
      )}
    </span>
  )
}

export function MatchInline({ score }: { score: number }) {
  return (
    <span className="inline-flex items-center gap-2">
      <MatchRing score={score} size={28} stroke={2.5} showValue={false} />
      <span className="flex flex-col leading-none">
        <span className={cn('text-sm font-semibold tabular', scoreColor(score))}>{score}%</span>
        <span className="mt-1 text-[10px] uppercase tracking-wider text-subtle-foreground">
          AI match
        </span>
      </span>
    </span>
  )
}

export function ScoreBar({ label, score }: { label: string; score: number }) {
  return (
    <div className="flex items-center gap-3">
      <span className="w-20 shrink-0 text-xs text-muted-foreground">{label}</span>
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/[0.06]">
        <div
          className={cn(
            'bar-in h-full rounded-full',
            score >= 85 ? 'bg-brand' : score >= 70 ? 'bg-[oklch(0.7_0.01_275)]' : 'bg-warning',
          )}
          style={{ width: `${score}%` }}
        />
      </div>
      <span className="w-8 text-right text-xs font-medium tabular text-foreground">{score}</span>
    </div>
  )
}
