import type { ComponentProps, ReactNode } from 'react'
import { ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils'

export function SelectField({
  label,
  className,
  children,
  icon,
  ...props
}: ComponentProps<'select'> & { label: string; icon?: ReactNode }) {
  return (
    <label className={cn('relative inline-flex h-8 items-center', className)}>
      <span className="sr-only">{label}</span>
      {icon && (
        <span className="pointer-events-none absolute left-2.5 text-subtle-foreground [&_svg]:size-3.5">{icon}</span>
      )}
      <select
        {...props}
        className={cn(
          'h-8 w-full cursor-pointer appearance-none rounded-md border border-border bg-white/[0.02] pr-8 text-sm text-foreground transition-colors hover:bg-white/[0.04] focus:border-brand/50 focus:outline-none focus:ring-2 focus:ring-brand/20',
          icon ? 'pl-8' : 'pl-2.5',
        )}
      >
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute right-2.5 size-3.5 text-subtle-foreground" aria-hidden="true" />
    </label>
  )
}

export const inputClass =
  'h-9 w-full rounded-md border border-border bg-white/[0.02] px-3 text-sm text-foreground placeholder:text-subtle-foreground transition-colors hover:border-border-strong focus:border-brand/50 focus:bg-white/[0.03] focus:outline-none focus:ring-2 focus:ring-brand/20'

export function Field({
  label,
  hint,
  htmlFor,
  children,
  className,
}: {
  label: string
  hint?: string
  htmlFor?: string
  children: ReactNode
  className?: string
}) {
  return (
    <div className={cn('flex flex-col gap-1.5', className)}>
      <label htmlFor={htmlFor} className="text-sm font-medium text-foreground">
        {label}
      </label>
      {children}
      {hint && <p className="text-xs text-subtle-foreground">{hint}</p>}
    </div>
  )
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  label,
}: {
  value: T
  onChange: (v: T) => void
  options: { value: T; label: string; count?: number }[]
  label: string
}) {
  return (
    <div role="tablist" aria-label={label} className="scrollbar-thin flex items-center gap-1 overflow-x-auto">
      {options.map((o) => {
        const active = o.value === value
        return (
          <button
            key={o.value}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(o.value)}
            className={cn(
              'inline-flex h-7 shrink-0 items-center gap-1.5 rounded-md px-2.5 text-sm transition-colors',
              active
                ? 'bg-white/[0.07] text-foreground ring-1 ring-inset ring-white/10'
                : 'text-muted-foreground hover:bg-white/[0.03] hover:text-foreground',
            )}
          >
            {o.label}
            {o.count !== undefined && (
              <span className={cn('text-xs tabular', active ? 'text-muted-foreground' : 'text-subtle-foreground')}>
                {o.count}
              </span>
            )}
          </button>
        )
      })}
    </div>
  )
}
