'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useMemo, useState } from 'react'
import { ArrowUpDown, Briefcase, ChevronLeft, ChevronRight, Search, Tag, X } from 'lucide-react'
import { candidates, jobs, type CandidateStatus } from '@/lib/data'
import { cn } from '@/lib/utils'
import { Avatar, ResumeBadge, SkillTag, StatusBadge } from '@/components/kit/primitives'
import { MatchInline, MatchRing } from '@/components/kit/match-score'
import { Segmented, SelectField } from '@/components/kit/controls'

type StatusFilter = 'All' | CandidateStatus
type SortKey = 'match' | 'recent' | 'experience' | 'name'

const statuses: StatusFilter[] = ['All', 'Applied', 'Screening', 'Shortlisted', 'Interview', 'Offer', 'Hired', 'Rejected']
const PAGE_SIZE = 8

const recencyRank = (v: string) => {
  const n = parseInt(v)
  if (v.endsWith('h')) return n
  if (v.endsWith('d')) return n * 24
  return n * 24 * 7
}

const allSkills = Array.from(new Set(candidates.flatMap((c) => c.skills))).sort()

export function CandidatesTable({ initialStatus }: { initialStatus?: string }) {
  const router = useRouter()
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState<StatusFilter>(
    statuses.includes(initialStatus as StatusFilter) ? (initialStatus as StatusFilter) : 'All',
  )
  const [job, setJob] = useState('all')
  const [skill, setSkill] = useState('all')
  const [sort, setSort] = useState<SortKey>('match')
  const [page, setPage] = useState(1)

  const resetPage = <T,>(setter: (v: T) => void) => (v: T) => {
    setter(v)
    setPage(1)
  }

  const counts = useMemo(() => {
    const map: Record<string, number> = { All: candidates.length }
    for (const c of candidates) map[c.status] = (map[c.status] ?? 0) + 1
    return map
  }, [])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    const list = candidates.filter((c) => {
      if (status !== 'All' && c.status !== status) return false
      if (job !== 'all' && c.jobId !== job) return false
      if (skill !== 'all' && !c.skills.includes(skill)) return false
      if (!q) return true
      return (
        c.name.toLowerCase().includes(q) ||
        c.currentTitle.toLowerCase().includes(q) ||
        c.currentCompany.toLowerCase().includes(q) ||
        c.skills.some((s) => s.toLowerCase().includes(q))
      )
    })
    return [...list].sort((a, b) => {
      if (sort === 'match') return b.match - a.match
      if (sort === 'experience') return b.experience - a.experience
      if (sort === 'name') return a.name.localeCompare(b.name)
      return recencyRank(a.lastActivity) - recencyRank(b.lastActivity)
    })
  }, [query, status, job, skill, sort])

  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const current = Math.min(page, pages)
  const rows = filtered.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE)
  const hasFilters = query || job !== 'all' || skill !== 'all' || status !== 'All'

  return (
    <div className="flex flex-col gap-4">
      <Segmented
        label="Filter by status"
        value={status}
        onChange={resetPage(setStatus)}
        options={statuses.map((s) => ({ value: s, label: s, count: counts[s] ?? 0 }))}
      />

      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <div className="flex flex-col gap-2 border-b border-border p-3 md:flex-row md:items-center">
          <label className="relative flex h-8 flex-1 items-center md:max-w-xs">
            <span className="sr-only">Search candidates</span>
            <Search className="pointer-events-none absolute left-2.5 size-3.5 text-subtle-foreground" aria-hidden="true" />
            <input
              value={query}
              onChange={(e) => resetPage(setQuery)(e.target.value)}
              placeholder="Name, company or skill"
              className="h-8 w-full rounded-md border border-border bg-white/[0.02] pl-8 pr-3 text-sm placeholder:text-subtle-foreground focus:border-brand/50 focus:outline-none focus:ring-2 focus:ring-brand/20"
            />
          </label>
          <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap md:ml-auto">
            <SelectField label="Filter by job" icon={<Briefcase />} value={job} onChange={(e) => resetPage(setJob)(e.target.value)} className="sm:w-48">
              <option value="all">All jobs</option>
              {jobs.filter((j) => j.status !== 'Draft').map((j) => (
                <option key={j.id} value={j.id}>{j.title}</option>
              ))}
            </SelectField>
            <SelectField label="Filter by skill" icon={<Tag />} value={skill} onChange={(e) => resetPage(setSkill)(e.target.value)} className="sm:w-40">
              <option value="all">Any skill</option>
              {allSkills.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </SelectField>
            <SelectField label="Sort by" icon={<ArrowUpDown />} value={sort} onChange={(e) => setSort(e.target.value as SortKey)} className="col-span-2 sm:w-44">
              <option value="match">Highest match</option>
              <option value="recent">Recent activity</option>
              <option value="experience">Most experience</option>
              <option value="name">Name A–Z</option>
            </SelectField>
            {hasFilters && (
              <button
                type="button"
                onClick={() => {
                  setQuery('')
                  setJob('all')
                  setSkill('all')
                  setStatus('All')
                  setPage(1)
                }}
                className="col-span-2 inline-flex h-8 items-center justify-center gap-1 rounded-md px-2 text-sm text-muted-foreground hover:bg-white/[0.04] hover:text-foreground"
              >
                <X className="size-3.5" aria-hidden="true" />
                Clear
              </button>
            )}
          </div>
        </div>

        {rows.length === 0 ? (
          <div className="flex flex-col items-center justify-center px-6 py-16 text-center">
            <p className="text-sm font-medium">No candidates match these filters</p>
            <p className="mt-1 text-sm text-muted-foreground">Try removing a filter or broadening your search.</p>
          </div>
        ) : (
          <>
            <table className="hidden w-full text-sm lg:table">
              <thead>
                <tr className="border-b border-border text-left text-xs text-subtle-foreground">
                  <th scope="col" className="px-4 py-2.5 font-medium">Candidate</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">AI match</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Applied for</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Skills</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Status</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Resume</th>
                  <th scope="col" className="px-4 py-2.5 text-right font-medium">Last activity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((c) => {
                  const j = jobs.find((x) => x.id === c.jobId)
                  return (
                    <tr
                      key={c.id}
                      onClick={() => router.push(`/candidates/${c.id}`)}
                      className="group cursor-pointer transition-colors hover:bg-white/[0.025]"
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <Avatar name={c.name} />
                          <div className="min-w-0">
                            <Link
                              href={`/candidates/${c.id}`}
                              onClick={(e) => e.stopPropagation()}
                              className="block truncate font-medium text-foreground hover:underline"
                            >
                              {c.name}
                            </Link>
                            <p className="truncate text-xs text-muted-foreground">
                              {c.currentTitle} at {c.currentCompany} · {c.experience} yrs
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <MatchInline score={c.match} />
                      </td>
                      <td className="px-4 py-3">
                        <p className="truncate text-foreground">{j?.title}</p>
                        <p className="text-xs text-subtle-foreground">{c.source}</p>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex max-w-60 flex-wrap gap-1">
                          {c.skills.slice(0, 3).map((s) => (
                            <SkillTag key={s} highlight={j?.skills.includes(s)}>{s}</SkillTag>
                          ))}
                          {c.skills.length > 3 && (
                            <span className="px-1 py-0.5 text-xs text-subtle-foreground">+{c.skills.length - 3}</span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
                      <td className="px-4 py-3"><ResumeBadge status={c.resume} /></td>
                      <td className="px-4 py-3 text-right">
                        <p className="text-foreground tabular">{c.lastActivity} ago</p>
                        <p className="truncate text-xs text-subtle-foreground">{c.lastActivityLabel}</p>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>

            <ul className="divide-y divide-border lg:hidden">
              {rows.map((c) => {
                const j = jobs.find((x) => x.id === c.jobId)
                return (
                  <li key={c.id}>
                    <Link href={`/candidates/${c.id}`} className="flex gap-3 p-4 transition-colors hover:bg-white/[0.02]">
                      <Avatar name={c.name} size="lg" />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <p className="truncate font-medium">{c.name}</p>
                            <p className="truncate text-xs text-muted-foreground">{j?.title} · {c.experience} yrs</p>
                          </div>
                          <MatchRing score={c.match} size={40} />
                        </div>
                        <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                          <StatusBadge status={c.status} />
                          {c.skills.slice(0, 2).map((s) => (
                            <SkillTag key={s} highlight={j?.skills.includes(s)}>{s}</SkillTag>
                          ))}
                          <span className="ml-auto text-xs text-subtle-foreground">{c.lastActivity} ago</span>
                        </div>
                      </div>
                    </Link>
                  </li>
                )
              })}
            </ul>
          </>
        )}

        <div className="flex items-center justify-between gap-4 border-t border-border px-4 py-3 text-xs text-muted-foreground">
          <p className="tabular">
            {filtered.length === 0
              ? '0 results'
              : `${(current - 1) * PAGE_SIZE + 1}–${Math.min(current * PAGE_SIZE, filtered.length)} of ${filtered.length}`}
          </p>
          <nav aria-label="Pagination" className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setPage(current - 1)}
              disabled={current === 1}
              className="inline-flex size-7 items-center justify-center rounded-md hover:bg-white/[0.05] disabled:opacity-40"
              aria-label="Previous page"
            >
              <ChevronLeft className="size-4" />
            </button>
            {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setPage(p)}
                aria-current={p === current ? 'page' : undefined}
                className={cn(
                  'inline-flex size-7 items-center justify-center rounded-md tabular transition-colors',
                  p === current ? 'bg-white/[0.07] text-foreground ring-1 ring-inset ring-white/10' : 'hover:bg-white/[0.04]',
                )}
              >
                {p}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setPage(current + 1)}
              disabled={current === pages}
              className="inline-flex size-7 items-center justify-center rounded-md hover:bg-white/[0.05] disabled:opacity-40"
              aria-label="Next page"
            >
              <ChevronRight className="size-4" />
            </button>
          </nav>
        </div>
      </div>
    </div>
  )
}
