'use client'

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  type TooltipContentProps,
} from 'recharts'
import { applicationsOverTime, qualityDistribution, timeToHire } from '@/lib/data'

const axis = { stroke: 'var(--subtle-foreground)', fontSize: 11, tickLine: false, axisLine: false } as const
const grid = { stroke: 'var(--border)', vertical: false } as const

function ChartTooltip({ active, payload, label, suffix = '' }: Partial<TooltipContentProps<number, string>> & { suffix?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-lg border border-border-strong bg-popover px-3 py-2 text-xs shadow-xl">
      <p className="mb-1 text-subtle-foreground">{label}</p>
      {payload.map((p) => (
        <p key={String(p.dataKey)} className="flex items-center gap-2 text-foreground">
          <span className="size-2 rounded-full" style={{ background: p.color }} aria-hidden="true" />
          <span className="capitalize text-muted-foreground">{String(p.name)}</span>
          <span className="ml-auto font-medium tabular">
            {p.value}
            {suffix}
          </span>
        </p>
      ))}
    </div>
  )
}

export function ApplicationsChart() {
  return (
    <div className="h-64" role="img" aria-label="Weekly applications and shortlisted candidates, trending upward over ten weeks">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={applicationsOverTime} margin={{ top: 8, right: 4, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="appsFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--brand)" stopOpacity={0.3} />
              <stop offset="100%" stopColor="var(--brand)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid {...grid} />
          <XAxis dataKey="week" {...axis} interval="preserveStartEnd" />
          <YAxis {...axis} />
          <Tooltip content={<ChartTooltip />} cursor={{ stroke: 'var(--border-strong)' }} />
          <Area type="monotone" dataKey="applications" stroke="var(--brand)" strokeWidth={1.75} fill="url(#appsFill)" />
          <Area type="monotone" dataKey="shortlisted" stroke="var(--success)" strokeWidth={1.75} fill="transparent" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}

export function TimeToHireChart() {
  return (
    <div className="h-48" role="img" aria-label="Average time to hire fell from 41 days in May to 27 days in October">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={timeToHire} margin={{ top: 8, right: 8, left: -24, bottom: 0 }}>
          <CartesianGrid {...grid} />
          <XAxis dataKey="month" {...axis} />
          <YAxis {...axis} domain={[20, 45]} />
          <Tooltip content={<ChartTooltip suffix=" days" />} cursor={{ stroke: 'var(--border-strong)' }} />
          <Line type="monotone" dataKey="days" stroke="var(--brand)" strokeWidth={2} dot={{ r: 3, fill: 'var(--card)', strokeWidth: 2 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

export function QualityChart() {
  return (
    <div className="h-48" role="img" aria-label="Distribution of candidate match scores; most fall between 70 and 79">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={qualityDistribution} margin={{ top: 8, right: 4, left: -24, bottom: 0 }}>
          <CartesianGrid {...grid} />
          <XAxis dataKey="band" {...axis} />
          <YAxis {...axis} />
          <Tooltip content={<ChartTooltip />} cursor={{ fill: 'oklch(1 0 0 / 3%)' }} />
          <Bar dataKey="count" name="candidates" radius={[4, 4, 0, 0]}>
            {qualityDistribution.map((d, i) => (
              <Cell key={d.band} fill={i >= 3 ? 'var(--brand)' : 'oklch(0.66 0.15 278 / 35%)'} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
