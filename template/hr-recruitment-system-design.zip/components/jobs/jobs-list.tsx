'use client'

import Link from 'next/link'
import { useState } from 'react'
import { MapPin, MoreHorizontal, Users } from 'lucide-react'
import { jobs, type JobStatus } from '@/lib/data'
import { Avatar, JobStatusBadge, SkillTag } from '@/components/kit/primitives'
import { Segmented } from '@/components/kit/controls'

type Filter = 'All' | JobStatus

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <p className="text-lg font-semibold tracking-tight tabular">{value}</p>
      <p className="text-xs text-subtle-foreground">{label}</p>
    </div>
  )
}

export function JobsList() {
  const [filter, setFilter] = useState<Filter>('Active')
  const count = (s: JobStatus) => jobs.filter((j) => j.status === s).length
  const list = filter === 'All' ? jobs : jobs.filter((j) => j.status === filter)

  return (
    <div className="flex flex-col gap-4">
      <Segmented
        label="Filter jobs by status"
        value={filter}
        onChange={setFilter}
        options={[
          { value: 'Active', label: 'Active', count: count('Active') },
          { value: 'Draft', label: 'Drafts', count: count('Draft') },
          { value: 'Closed', label: 'Closed', count: count('Closed') },
          { value: 'All', label: 'All', count: jobs.length },
        ]}
      />

      <ul className="flex flex-col gap-3">
        {list.map((j) => {
          const conversion = j.applicants ? Math.round((j.shortlisted / j.applicants) * 1000) / 10 : 0
          return (
            <li
              key={j.id}
              className="group rounded-xl border border-border bg-card transition-colors hover:border-border-strong"
            >
              <div className="flex flex-col gap-5 p-5 lg:flex-row lg:items-center">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <Link
                      href="/candidates"
                      className="text-base font-medium text-foreground hover:underline"
                    >
                      {j.title}
                    </Link>
                    <JobStatusBadge status={j.status} />
                  </div>
                  <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
                    <span>{j.department}</span>
                    <span className="flex items-center gap-1">
                      <MapPin className="size-3.5" aria-hidden="true" />
                      {j.location}
                    </span>
                    <span>{j.type}</span>
                    <span className="text-subtle-foreground">Posted {j.postedAt}</span>
                  </p>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {j.skills.map((s) => (
                      <SkillTag key={s}>{s}</SkillTag>
                    ))}
                  </div>
                </div>

                {j.status === 'Draft' ? (
                  <div className="flex items-center gap-3 lg:w-[420px] lg:justify-end">
                    <p className="text-sm text-muted-foreground">Not published yet</p>
                    <Link
                      href="/jobs/new"
                      className="inline-flex h-8 items-center rounded-md bg-white/[0.05] px-3 text-sm ring-1 ring-inset ring-white/10 transition-colors hover:bg-white/[0.08]"
                    >
                      Continue editing
                    </Link>
                  </div>
                ) : (
                  <div className="grid grid-cols-4 items-center gap-4 lg:w-[420px]">
                    <Metric label="Applicants" value={j.applicants} />
                    <Metric label="Shortlisted" value={j.shortlisted} />
                    <Metric label="Interviews" value={j.interviews} />
                    <div>
                      <p className="text-lg font-semibold tracking-tight tabular">{conversion}%</p>
                      <div className="mt-1 h-1 overflow-hidden rounded-full bg-white/[0.06]">
                        <div className="bar-in h-full rounded-full bg-brand" style={{ width: `${Math.min(conversion * 6, 100)}%` }} />
                      </div>
                      <p className="mt-1 text-xs text-subtle-foreground">Conversion</p>
                    </div>
                  </div>
                )}
              </div>
              <div className="flex items-center justify-between gap-3 border-t border-border px-5 py-2.5">
                <span className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Avatar name={j.hiringManager} size="sm" />
                  {j.hiringManager}
                  <span className="text-subtle-foreground">· Hiring manager</span>
                </span>
                <div className="flex items-center gap-1">
                  {j.status !== 'Draft' && (
                    <Link
                      href="/candidates"
                      className="inline-flex h-7 items-center gap-1.5 rounded-md px-2 text-xs text-muted-foreground transition-colors hover:bg-white/[0.05] hover:text-foreground"
                    >
                      <Users className="size-3.5" aria-hidden="true" />
                      View pipeline
                    </Link>
                  )}
                  <button
                    type="button"
                    className="inline-flex size-7 items-center justify-center rounded-md text-muted-foreground hover:bg-white/[0.05] hover:text-foreground"
                    aria-label={`More actions for ${j.title}`}
                  >
                    <MoreHorizontal className="size-4" />
                  </button>
                </div>
              </div>
            </li>
          )
        })}
      </ul>
    </div>
  )
}
