'use client'

import { useRouter } from 'next/navigation'
import { useState, type KeyboardEvent } from 'react'
import { Loader2, Sparkles, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Field, SelectField, inputClass } from '@/components/kit/controls'
import { Panel } from '@/components/kit/primitives'
import { cn } from '@/lib/utils'

const generated = {
  description:
    'We are looking for a Senior Backend Engineer to design and scale the core services that power our hiring platform. You will own high-throughput APIs, data pipelines and the infrastructure behind real-time candidate evaluation.\n\nWhat you will do\n• Design and build distributed services in Go and C++\n• Model data and optimize queries in PostgreSQL\n• Partner with product and ML teams on new capabilities\n• Raise the bar on reliability, observability and code quality',
  requirements:
    '• 5+ years building production backend systems\n• Deep experience with distributed systems and PostgreSQL\n• Comfortable operating services on AWS\n• Clear written communication in English',
  skills: ['Go', 'C++', 'PostgreSQL', 'Distributed systems', 'AWS'],
}

export function JobForm() {
  const router = useRouter()
  const [title, setTitle] = useState('Senior Backend Engineer')
  const [skills, setSkills] = useState<string[]>(['Go', 'PostgreSQL'])
  const [skillInput, setSkillInput] = useState('')
  const [description, setDescription] = useState('')
  const [requirements, setRequirements] = useState('')
  const [generating, setGenerating] = useState(false)
  const [saving, setSaving] = useState<null | 'draft' | 'publish'>(null)

  const addSkill = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.nativeEvent.isComposing || e.keyCode === 229) return
    if ((e.key === 'Enter' || e.key === ',') && skillInput.trim()) {
      e.preventDefault()
      const value = skillInput.trim()
      if (!skills.includes(value)) setSkills([...skills, value])
      setSkillInput('')
    } else if (e.key === 'Backspace' && !skillInput && skills.length) {
      setSkills(skills.slice(0, -1))
    }
  }

  const generate = () => {
    setGenerating(true)
    setTimeout(() => {
      setDescription(generated.description)
      setRequirements(generated.requirements)
      setSkills((prev) => Array.from(new Set([...prev, ...generated.skills])))
      setGenerating(false)
    }, 1100)
  }

  const submit = (mode: 'draft' | 'publish') => {
    setSaving(mode)
    setTimeout(() => router.push('/jobs'), 600)
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault()
        submit('publish')
      }}
      className="grid grid-cols-1 gap-6 xl:grid-cols-3"
    >
      <div className="flex flex-col gap-6 xl:col-span-2">
        <Panel title="Role" description="Basic information shown on the job posting.">
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <Field label="Job title" htmlFor="title" className="sm:col-span-2">
              <input id="title" required value={title} onChange={(e) => setTitle(e.target.value)} className={inputClass} placeholder="e.g. Senior Backend Engineer" />
            </Field>
            <Field label="Department">
              <SelectField label="Department" defaultValue="Engineering" className="h-9 w-full">
                <option>Engineering</option>
                <option>Design</option>
                <option>AI Platform</option>
                <option>Operations</option>
                <option>People</option>
                <option>Sales</option>
              </SelectField>
            </Field>
            <Field label="Location" htmlFor="location">
              <input id="location" defaultValue="Berlin · Hybrid" className={inputClass} />
            </Field>
            <Field label="Employment type">
              <SelectField label="Employment type" defaultValue="Full-time" className="h-9 w-full">
                <option>Full-time</option>
                <option>Part-time</option>
                <option>Contract</option>
              </SelectField>
            </Field>
            <Field label="Minimum experience">
              <SelectField label="Minimum experience" defaultValue="5" className="h-9 w-full">
                {[0, 1, 2, 3, 4, 5, 6, 8, 10].map((n) => (
                  <option key={n} value={n}>{n === 0 ? 'No minimum' : `${n}+ years`}</option>
                ))}
              </SelectField>
            </Field>
          </div>
        </Panel>

        <Panel
          title="Description"
          description="Used for the public posting and as context for AI candidate evaluation."
          action={
            <Button type="button" variant="outline" size="sm" onClick={generate} disabled={generating || !title}>
              {generating ? <Loader2 className="animate-spin" aria-hidden="true" /> : <Sparkles className="text-brand" aria-hidden="true" />}
              {generating ? 'Generating…' : 'Generate with AI'}
            </Button>
          }
        >
          <div className="flex flex-col gap-5">
            <Field label="Job description" htmlFor="description">
              <textarea
                id="description"
                rows={9}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the role, the team and what success looks like…"
                className={cn(inputClass, 'h-auto resize-y py-2.5 leading-relaxed', generating && 'animate-pulse')}
              />
            </Field>
            <Field label="Hiring requirements" htmlFor="requirements" hint="One requirement per line. These are weighted most heavily in AI match scores.">
              <textarea
                id="requirements"
                rows={5}
                value={requirements}
                onChange={(e) => setRequirements(e.target.value)}
                placeholder="• 5+ years of …"
                className={cn(inputClass, 'h-auto resize-y py-2.5 leading-relaxed', generating && 'animate-pulse')}
              />
            </Field>
          </div>
        </Panel>
      </div>

      <div className="flex flex-col gap-6">
        <Panel title="Required skills" description="Press Enter to add a skill.">
          <div className="flex min-h-9 flex-wrap items-center gap-1.5 rounded-md border border-border bg-white/[0.02] p-1.5 focus-within:border-brand/50 focus-within:ring-2 focus-within:ring-brand/20">
            {skills.map((s) => (
              <span key={s} className="inline-flex items-center gap-1 rounded bg-brand/10 py-0.5 pl-1.5 pr-0.5 text-xs text-foreground ring-1 ring-inset ring-brand/25">
                {s}
                <button
                  type="button"
                  onClick={() => setSkills(skills.filter((x) => x !== s))}
                  className="rounded p-0.5 text-muted-foreground hover:bg-white/10 hover:text-foreground"
                  aria-label={`Remove ${s}`}
                >
                  <X className="size-3" />
                </button>
              </span>
            ))}
            <label className="min-w-24 flex-1">
              <span className="sr-only">Add skill</span>
              <input
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyDown={addSkill}
                placeholder={skills.length ? 'Add…' : 'e.g. TypeScript'}
                className="h-6 w-full bg-transparent px-1 text-sm placeholder:text-subtle-foreground focus:outline-none"
              />
            </label>
          </div>
        </Panel>

        <Panel title="AI screening">
          <div className="flex flex-col gap-4 text-sm">
            {[
              { id: 'auto-eval', label: 'Evaluate new applicants automatically', on: true },
              { id: 'auto-shortlist', label: 'Suggest shortlist above 85% match', on: true },
              { id: 'auto-reject', label: 'Auto-reject below 50% match', on: false },
            ].map((o) => (
              <label key={o.id} htmlFor={o.id} className="flex cursor-pointer items-start justify-between gap-4">
                <span className="text-muted-foreground">{o.label}</span>
                <input id={o.id} type="checkbox" defaultChecked={o.on} className="peer sr-only" />
                <span
                  aria-hidden="true"
                  className="relative mt-0.5 h-4 w-7 shrink-0 rounded-full bg-white/10 transition-colors after:absolute after:left-0.5 after:top-0.5 after:size-3 after:rounded-full after:bg-foreground after:transition-transform peer-checked:bg-brand peer-checked:after:translate-x-3 peer-focus-visible:ring-2 peer-focus-visible:ring-brand/40"
                />
              </label>
            ))}
          </div>
        </Panel>

        <div className="flex flex-col gap-2 xl:sticky xl:top-20">
          <Button type="submit" variant="default" size="lg" disabled={saving !== null}>
            {saving === 'publish' && <Loader2 className="animate-spin" aria-hidden="true" />}
            Publish job
          </Button>
          <Button type="button" variant="ghost" size="lg" disabled={saving !== null} onClick={() => submit('draft')}>
            {saving === 'draft' && <Loader2 className="animate-spin" aria-hidden="true" />}
            Save as draft
          </Button>
        </div>
      </div>
    </form>
  )
}
