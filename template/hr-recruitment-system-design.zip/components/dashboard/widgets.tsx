import Link from 'next/link'
import { ArrowRight, ArrowUpRight, ArrowDownRight, Video, Building2 } from 'lucide-react'
import { candidates, getCandidate, getJob, interviews, pipeline } from '@/lib/data'
import { cn } from '@/lib/utils'
import { Avatar, Panel, StatusBadge } from '@/components/kit/primitives'
import { MatchRing } from '@/components/kit/match-score'

function Sparkline({ data }: { data: number[] }) {
  const w = 80
  const h = 24
  const min = Math.min(...data)
  const max = Math.max(...data)
  const pts = data
    .map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / (max - min || 1)) * (h - 4) - 2}`)
    .join(' ')
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} aria-hidden="true" className="overflow-visible">
      <polyline points={pts} fill="none" strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" className="stroke-brand/70" />
    </svg>
  )
}

const stats = [
  { label: 'Total candidates', value: '1,123', delta: '+12.4%', up: true, note: 'vs. last 30 days', spark: [40, 44, 42, 51, 56, 54, 61, 66, 64, 72] },
  { label: 'Active job openings', value: '5', delta: '+1', up: true, note: '2 drafts pending', spark: [3, 3, 4, 4, 4, 5, 4, 4, 5, 5] },
  { label: 'Shortlisted', value: '100', delta: '+18.0%', up: true, note: '8.9% of applicants', spark: [11, 14, 12, 17, 19, 22, 21, 26, 28, 31] },
  { label: 'Upcoming interviews', value: '6', delta: '−2', up: false, note: 'Next: today 14:00', spark: [9, 8, 10, 7, 9, 8, 7, 8, 7, 6] },
]

export function StatGrid() {
  return (
    <div className="grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2 xl:grid-cols-4">
      {stats.map((s) => (
        <div key={s.label} className="flex flex-col bg-card p-5">
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">{s.label}</p>
            <span
              className={cn(
                'inline-flex items-center gap-0.5 text-xs font-medium tabular',
                s.up ? 'text-success' : 'text-muted-foreground',
              )}
            >
              {s.up ? <ArrowUpRight className="size-3" aria-hidden="true" /> : <ArrowDownRight className="size-3" aria-hidden="true" />}
              {s.delta}
            </span>
          </div>
          <div className="mt-3 flex items-end justify-between gap-4">
            <p className="text-3xl font-semibold tracking-tight tabular text-foreground">{s.value}</p>
            <Sparkline data={s.spark} />
          </div>
          <p className="mt-2 text-xs text-subtle-foreground">{s.note}</p>
        </div>
      ))}
    </div>
  )
}

export function PipelineFunnel() {
  const max = pipeline[0].count
  return (
    <Panel
      title="Recruitment pipeline"
      description="All active jobs · last 30 days"
      action={
        <Link href="/analytics" className="text-xs text-muted-foreground transition-colors hover:text-foreground">
          View analytics
        </Link>
      }
    >
      <ol className="grid grid-cols-1 gap-4 sm:grid-cols-5 sm:gap-0">
        {pipeline.map((p, i) => {
          const next = pipeline[i + 1]
          const conv = next ? Math.round((next.count / p.count) * 1000) / 10 : null
          const pct = Math.max((p.count / max) * 100, 4)
          return (
            <li key={p.stage} className="relative flex flex-col sm:pr-4">
              <div className="flex items-baseline justify-between gap-2 sm:block">
                <p className="text-xs text-muted-foreground">{p.stage}</p>
                <p className="mt-1 text-2xl font-semibold tracking-tight tabular">{p.count.toLocaleString()}</p>
              </div>
              <div className="mt-3 h-16 overflow-hidden rounded-md bg-white/[0.03] sm:h-24">
                <div className="flex h-full items-end">
                  <div
                    className={cn(
                      'bar-in w-full rounded-md',
                      i === pipeline.length - 1 ? 'bg-success/80' : i >= 2 ? 'bg-brand' : 'bg-brand/40',
                    )}
                    style={{ height: `${pct}%`, animationDelay: `${i * 60}ms` }}
                  />
                </div>
              </div>
              {conv !== null && (
                <p className="mt-2 flex items-center gap-1 text-xs text-subtle-foreground">
                  <ArrowRight className="size-3" aria-hidden="true" />
                  <span className="tabular text-muted-foreground">{conv}%</span> to {next!.stage.toLowerCase()}
                </p>
              )}
              {conv === null && <p className="mt-2 text-xs text-subtle-foreground">0.8% overall</p>}
            </li>
          )
        })}
      </ol>
    </Panel>
  )
}

export function RecentCandidates() {
  const recent = candidates.filter((c) => c.status !== 'Rejected' && c.status !== 'Hired').slice(0, 6)
  return (
    <Panel
      title="Recent candidates"
      action={
        <Link href="/candidates" className="text-xs text-muted-foreground transition-colors hover:text-foreground">
          View all
        </Link>
      }
      bodyClassName="p-0"
    >
      <ul className="divide-y divide-border">
        {recent.map((c) => (
          <li key={c.id}>
            <Link
              href={`/candidates/${c.id}`}
              className="flex items-center gap-3 px-5 py-3 transition-colors hover:bg-white/[0.02]"
            >
              <Avatar name={c.name} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-foreground">{c.name}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {getJob(c.jobId)?.title} · {c.experience} yrs
                </p>
              </div>
              <div className="hidden sm:block">
                <StatusBadge status={c.status} />
              </div>
              <span className="hidden w-10 text-right text-xs text-subtle-foreground md:block">{c.lastActivity}</span>
              <MatchRing score={c.match} />
            </Link>
          </li>
        ))}
      </ul>
    </Panel>
  )
}

export function UpcomingInterviews() {
  const upcoming = interviews.filter((i) => i.status === 'Scheduled').slice(0, 4)
  return (
    <Panel
      title="Upcoming interviews"
      action={
        <Link href="/interviews" className="text-xs text-muted-foreground transition-colors hover:text-foreground">
          Schedule
        </Link>
      }
      bodyClassName="p-0"
    >
      <ul className="divide-y divide-border">
        {upcoming.map((i) => {
          const c = getCandidate(i.candidateId)!
          const ModeIcon = i.mode === 'Video' ? Video : Building2
          return (
            <li key={i.id} className="flex items-center gap-4 px-5 py-3">
              <div className="w-14 shrink-0">
                <p className="text-sm font-medium tabular">{i.time}</p>
                <p className="text-xs text-subtle-foreground">{i.day}</p>
              </div>
              <div className="min-w-0 flex-1 border-l border-border pl-4">
                <Link href={`/candidates/${c.id}`} className="block truncate text-sm text-foreground hover:underline">
                  {c.name}
                </Link>
                <p className="flex items-center gap-1.5 truncate text-xs text-muted-foreground">
                  <ModeIcon className="size-3" aria-hidden="true" />
                  {i.stage} · {i.duration} min
                </p>
              </div>
            </li>
          )
        })}
      </ul>
    </Panel>
  )
}
