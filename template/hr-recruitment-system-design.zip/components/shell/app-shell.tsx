'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState, type ReactNode } from 'react'
import {
  BarChart3,
  Bell,
  Briefcase,
  CalendarClock,
  ChevronsUpDown,
  LayoutGrid,
  Menu,
  Plus,
  Search,
  Settings,
  Sparkles,
  Users,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Avatar, Kbd } from '@/components/kit/primitives'

type NavItem = { href: string; label: string; icon: typeof Users; count?: number }

const nav: { heading?: string; items: NavItem[] }[] = [
  { items: [{ href: '/', label: 'Overview', icon: LayoutGrid }] },
  {
    heading: 'Recruitment',
    items: [
      { href: '/candidates', label: 'Candidates', icon: Users, count: 1123 },
      { href: '/jobs', label: 'Jobs', icon: Briefcase, count: 5 },
      { href: '/interviews', label: 'Interviews', icon: CalendarClock, count: 6 },
    ],
  },
  {
    heading: 'Insights',
    items: [
      { href: '/insights', label: 'AI Insights', icon: Sparkles, count: 6 },
      { href: '/analytics', label: 'Analytics', icon: BarChart3 },
    ],
  },
  { heading: 'System', items: [{ href: '/settings', label: 'Settings', icon: Settings }] },
]

function isActive(pathname: string, href: string) {
  return href === '/' ? pathname === '/' : pathname.startsWith(href)
}

function Logo() {
  return (
    <span className="flex size-6 items-center justify-center rounded-md bg-foreground text-background">
      <svg viewBox="0 0 16 16" className="size-3.5" aria-hidden="true">
        <path d="M3 13V3h5.5a3 3 0 0 1 0 6H6l5 4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </span>
  )
}

function SidebarContent({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-14 items-center gap-2 px-3">
        <button
          type="button"
          className="flex min-w-0 flex-1 items-center gap-2.5 rounded-md px-1.5 py-1.5 text-left transition-colors hover:bg-sidebar-accent"
        >
          <Logo />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-medium leading-tight">Relay</span>
            <span className="block truncate text-[11px] leading-tight text-subtle-foreground">
              Acme Inc. · Talent
            </span>
          </span>
          <ChevronsUpDown className="size-3.5 text-subtle-foreground" aria-hidden="true" />
        </button>
      </div>

      <div className="px-3 pb-2">
        <Link
          href="/jobs/new"
          onClick={onNavigate}
          className="flex h-8 w-full items-center gap-2 rounded-md border border-border-strong bg-white/[0.03] px-2.5 text-sm text-muted-foreground transition-colors hover:bg-white/[0.06] hover:text-foreground"
        >
          <Plus className="size-4" aria-hidden="true" />
          New job
          <span className="ml-auto">
            <Kbd>N</Kbd>
          </span>
        </Link>
      </div>

      <nav aria-label="Primary" className="scrollbar-thin flex-1 overflow-y-auto px-3 py-2">
        {nav.map((group, gi) => (
          <div key={gi} className={cn(gi > 0 && 'mt-5')}>
            {group.heading && (
              <p className="mb-1 px-2 text-[11px] font-medium text-subtle-foreground">
                {group.heading}
              </p>
            )}
            <ul className="flex flex-col gap-px">
              {group.items.map((item) => {
                const active = isActive(pathname, item.href)
                const Icon = item.icon
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      onClick={onNavigate}
                      aria-current={active ? 'page' : undefined}
                      className={cn(
                        'group relative flex h-8 items-center gap-2.5 rounded-md px-2 text-sm transition-colors',
                        active
                          ? 'bg-sidebar-accent text-foreground'
                          : 'text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground',
                      )}
                    >
                      {active && (
                        <span
                          aria-hidden="true"
                          className="absolute inset-y-1.5 -left-3 w-0.5 rounded-r-full bg-brand"
                        />
                      )}
                      <Icon
                        className={cn(
                          'size-4 transition-colors',
                          active ? 'text-brand' : 'text-subtle-foreground group-hover:text-muted-foreground',
                        )}
                        aria-hidden="true"
                      />
                      {item.label}
                      {item.count !== undefined && (
                        <span className="ml-auto text-xs tabular text-subtle-foreground">
                          {item.count.toLocaleString()}
                        </span>
                      )}
                    </Link>
                  </li>
                )
              })}
            </ul>
          </div>
        ))}
      </nav>

      <div className="border-t border-sidebar-border p-3">
        <div className="mb-3 rounded-lg border border-border bg-white/[0.02] p-3">
          <div className="flex items-center gap-2 text-xs font-medium text-foreground">
            <Sparkles className="size-3.5 text-brand" aria-hidden="true" />
            AI screening
          </div>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
            842 of 1,000 monthly evaluations used.
          </p>
          <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/[0.06]">
            <div className="h-full w-[84%] rounded-full bg-brand" />
          </div>
        </div>
        <div className="flex items-center gap-2.5 px-1">
          <Avatar name="Elena Sousa" size="sm" />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm leading-tight">Elena Sousa</p>
            <p className="truncate text-[11px] leading-tight text-subtle-foreground">
              Head of Talent
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function Topbar({ onMenu }: { onMenu: () => void }) {
  return (
    <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-border bg-background/80 px-4 backdrop-blur-md sm:px-6">
      <button
        type="button"
        onClick={onMenu}
        className="-ml-1.5 inline-flex size-8 items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground lg:hidden"
        aria-label="Open navigation"
      >
        <Menu className="size-4" />
      </button>
      <div className="lg:hidden">
        <Logo />
      </div>
      <label className="group relative flex h-8 w-full max-w-md items-center">
        <span className="sr-only">Search candidates, jobs and interviews</span>
        <Search className="pointer-events-none absolute left-2.5 size-4 text-subtle-foreground" aria-hidden="true" />
        <input
          type="search"
          placeholder="Search candidates, jobs, skills…"
          className="h-8 w-full rounded-md border border-border bg-white/[0.02] pl-8 pr-12 text-sm text-foreground placeholder:text-subtle-foreground transition-colors focus:border-brand/50 focus:bg-white/[0.04] focus:outline-none focus:ring-2 focus:ring-brand/20"
        />
        <span className="pointer-events-none absolute right-2 hidden items-center gap-0.5 sm:flex">
          <Kbd>⌘</Kbd>
          <Kbd>K</Kbd>
        </span>
      </label>
      <div className="ml-auto flex items-center gap-1">
        <button
          type="button"
          className="relative inline-flex size-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          aria-label="Notifications, 3 unread"
        >
          <Bell className="size-4" />
          <span className="absolute right-2 top-2 size-1.5 rounded-full bg-brand ring-2 ring-background" />
        </button>
      </div>
    </header>
  )
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [open])

  return (
    <div className="flex min-h-dvh">
      <aside className="sticky top-0 hidden h-dvh w-60 shrink-0 border-r border-sidebar-border bg-sidebar lg:block">
        <SidebarContent pathname={pathname} />
      </aside>

      <div
        className={cn(
          'fixed inset-0 z-40 lg:hidden',
          open ? 'pointer-events-auto' : 'pointer-events-none',
        )}
        aria-hidden={!open}
      >
        <div
          className={cn(
            'absolute inset-0 bg-black/60 transition-opacity duration-200',
            open ? 'opacity-100' : 'opacity-0',
          )}
          onClick={() => setOpen(false)}
        />
        <aside
          role="dialog"
          aria-modal="true"
          aria-label="Navigation"
          className={cn(
            'absolute inset-y-0 left-0 w-72 border-r border-sidebar-border bg-sidebar shadow-2xl transition-transform duration-200 ease-out',
            open ? 'translate-x-0' : '-translate-x-full',
          )}
        >
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="absolute right-3 top-3.5 inline-flex size-7 items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Close navigation"
          >
            <X className="size-4" />
          </button>
          {open && <SidebarContent pathname={pathname} onNavigate={() => setOpen(false)} />}
        </aside>
      </div>

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar onMenu={() => setOpen(true)} />
        <main key={pathname} className="page-in mx-auto w-full max-w-[1400px] flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
          {children}
        </main>
      </div>
    </div>
  )
}
